"use client";


import ProtectedRoute from "@/components/ProtectedRoute";
import { useLanguage } from "@/context/LanguageContext";
import { motion, AnimatePresence } from "framer-motion";
import { DollarSign, Search, FileText, Download, TrendingUp, AlertCircle, Loader2, Receipt, X } from "lucide-react";
import { useState, useEffect } from "react";
import { hrService } from "@/services/hrservice";
import { avanceService } from "@/services/avanceService";
import dailyAttendanceService from "@/services/DailyattendanceService";

const AVATAR_COLORS = [
  "bg-emerald-500/20 text-emerald-400","bg-blue-500/20 text-blue-400",
  "bg-purple-500/20 text-purple-400","bg-amber-500/20 text-amber-400",
  "bg-pink-500/20 text-pink-400","bg-teal-500/20 text-teal-400",
  "bg-red-500/20 text-red-400","bg-indigo-500/20 text-indigo-400",
];
const STATUS_STYLES: Record<string, { badge: string; dot: string }> = {
  Active:     { badge: "bg-emerald-500/15 text-emerald-400", dot: "bg-emerald-400" },
  "On Leave": { badge: "bg-blue-500/15 text-blue-400",       dot: "bg-blue-400"    },
  Inactive:   { badge: "bg-red-500/15 text-red-400",         dot: "bg-red-400"     },
};

interface Employee {
  _id: string; name: string; email: string; position: string;
  department: string; salary: number; joinedDate: string; status: string;
}
interface AttSummary {
  presentDays: number; absentDays: number; lateDays: number; totalExtraHours: number;
}
interface PayrollRow {
  emp: Employee;
  base: number; brut: number; cnss: number; cnssEmployee: number; cnssEmployer: number; cnssTotal: number;
  avances: number; overtime: number;
  absenceDays: number; absenceDeduction: number; net: number; netAgreed: number;
}

// ── CNSS constants (Tunisian Labour Law) ─────────────────────────────────────
const CNSS_EMPLOYEE_RATE = 0.0967;   // 9.67%  deducted from employee brut
const CNSS_EMPLOYER_RATE = 0.2000;   // 20.00% paid by employer on top
const CNSS_TOTAL_RATE    = CNSS_EMPLOYEE_RATE + CNSS_EMPLOYER_RATE; // 29.67%

// The salary stored in DB is the AGREED NET the employee receives in hand.
// Brut is back-calculated: brut = netAgreed / (1 - CNSS_EMPLOYEE_RATE)
// So: brut - (brut × 9.67%) = netAgreed  ✓

function calcRow(emp: Employee, avances: any[], att?: AttSummary): PayrollRow {
  const netAgreed = emp.salary || 0;                         // agreed salary — always the take-home
  const brut      = Math.round(netAgreed / (1 - CNSS_EMPLOYEE_RATE)); // brut = net / 0.9033 ≈ net × 1.107
  const daily     = brut / 26;
  const hourly    = brut / 208;

  const absenceDays      = att?.absentDays ?? 0;
  const absenceDeduction = Math.round(daily * absenceDays);
  const effectiveDays    = Math.max(0, 26 - absenceDays);
  const effectiveBase    = Math.round(daily * effectiveDays); // earned brut based on hours
  const overtimePay      = att ? Math.round(hourly * (att.totalExtraHours || 0)) : 0;

  const grossSalary = effectiveBase + overtimePay;

  // CNSS — informational only, NOT deducted from net
  const cnssEmployee = Math.round(grossSalary * CNSS_EMPLOYEE_RATE); // 9.67% — shown on payslip
  const cnssEmployer = Math.round(grossSalary * CNSS_EMPLOYER_RATE); // 20%   — company cost
  const cnssTotal    = cnssEmployee + cnssEmployer;                  // 29.67%

  // Avance — the only real deduction from the agreed net
  const avTotal = avances
    .filter(a => a.employeeId === emp._id && (a.status === "Deducted" || a.status === "approved" || a.approved))
    .reduce((s: number, a: any) => s + (a.amount || 0), 0);

  // Net = agreed salary − avance only (CNSS is NOT deducted here)
  const net = netAgreed - avTotal;

  return {
    emp,
    base: effectiveBase,   // earned brut based on hours worked
    brut: grossSalary,     // total brut (base + overtime)
    cnss: cnssTotal,       // 29.67% total CNSS — informational
    cnssEmployee,          // 9.67% employee portion — shown on payslip
    cnssEmployer,          // 20.00% employer portion — shown on payslip
    cnssTotal,
    avances: avTotal,
    overtime: overtimePay,
    absenceDays,
    absenceDeduction,
    net,                   // agreed salary − avance (CNSS not deducted)
    netAgreed,
  };
}

// ── jsPDF payslip download ────────────────────────────────────────────────────
function r2(n: number) { return Math.round(n * 1000) / 1000; }

function monthLabel(m: string) {
  const [y, mo] = m.split("-");
  return new Date(Number(y), Number(mo) - 1).toLocaleString("en-US", { month: "long", year: "numeric" });
}

async function downloadPayslipPDF(
  emp: Employee,
  records: any[],
  empAvances: any[],
  fromMonth: string,
  toMonth: string,
) {
  const { default: jsPDF } = await import("jspdf");
  const { default: autoTable } = await import("jspdf-autotable");

  const [fy, fm] = fromMonth.split("-").map(Number);
  const [ty, tm] = toMonth.split("-").map(Number);
  const now        = new Date();
  const dateFrom   = new Date(fy, fm - 1, 1).toLocaleDateString("en-GB");
  const dateTo     = new Date(ty, tm, 0).toLocaleDateString("en-GB");
  const periodLabel = fromMonth === toMonth
    ? new Date(fy, fm - 1).toLocaleString("en-US", { month: "long", year: "numeric" })
    : `${new Date(fy, fm - 1).toLocaleString("en-US", { month: "short", year: "numeric" })} – ${new Date(ty, tm - 1).toLocaleString("en-US", { month: "short", year: "numeric" })}`;

  const hourlyRate = emp.salary ? emp.salary / 208 : 0;
  const avTotal    = empAvances.reduce((s: number, a: any) => s + (a.amount || 0), 0);

  const doc  = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
  const W    = doc.internal.pageSize.getWidth();
  const DARK = [13, 17, 23] as [number,number,number];
  const GREEN= [52, 211, 153] as [number,number,number];
  const GRAY = [107, 114, 128] as [number,number,number];

  // Header bar
  doc.setFillColor(...DARK);
  doc.rect(0, 0, W, 30, "F");
  doc.setTextColor(...GREEN);
  doc.setFontSize(16); doc.setFont("helvetica", "bold");
  doc.text("Pay Slip", 14, 12);
  doc.setFontSize(8); doc.setFont("helvetica", "normal"); doc.setTextColor(...GRAY);
  doc.text(`${periodLabel.toUpperCase()}  ·  EMM HARDWARE ERP`, 14, 19);
  doc.setFillColor(13, 46, 30);
  doc.roundedRect(W - 36, 8, 22, 8, 2, 2, "F");
  doc.setTextColor(...GREEN); doc.setFontSize(7); doc.setFont("helvetica", "bold");
  doc.text("EMM ERP", W - 25, 13.2, { align: "center" });

  // 3-col info strip
  const infoY = 36;
  doc.setFontSize(7); doc.setFont("helvetica", "bold"); doc.setTextColor(...GRAY);
  doc.text("EMPLOYER", 14, infoY);
  doc.text("PERIOD", W/2 - 10, infoY);
  doc.text("EMPLOYEE", W - 65, infoY);
  doc.setFontSize(8.5); doc.setFont("helvetica", "bold"); doc.setTextColor(255,255,255);
  doc.text("EMM Hardware", 14, infoY + 6);
  doc.text(`From ${dateFrom}`, W/2 - 10, infoY + 6);
  doc.text(emp.name, W - 65, infoY + 6);
  doc.setFontSize(7.5); doc.setFont("helvetica", "normal"); doc.setTextColor(...GRAY);
  doc.text("Sfax, Tunisia", 14, infoY + 12);
  doc.text(`To ${dateTo}`, W/2 - 10, infoY + 12);
  doc.text(`${emp.position}  ·  ${emp.department}`, W - 65, infoY + 12);
  doc.text("contact@emm.tn  |  CNSS: 2138", 14, infoY + 17);
  const seniority = emp.joinedDate ? `${Math.floor((Date.now()-new Date(emp.joinedDate).getTime())/(1000*60*60*24*365))} yrs` : "—";
  doc.text(`${emp.email}  |  Seniority: ${seniority}`, W - 65, infoY + 17);
  doc.setDrawColor(31, 41, 55);
  doc.line(14, infoY + 22, W - 14, infoY + 22);

  // Daily rows table — matching the Excel structure
  const salary2     = emp.salary || 0;
  const tableBody: string[][] = records.map(r => {
    const hoursWorked = r.hoursWorked ?? 0;
    const extraHours  = r.extraHours  ?? 0;
    const baseSalary  = salary2;                                // monthly base salary
    const reduction   = r2(Math.max(0, 8 - hoursWorked) * hourlyRate);
    const netDay      = r2(hoursWorked * hourlyRate);   // actual hours × rate
    return [
      r.date,
      hourlyRate.toFixed(2),
      "208",
      String(hoursWorked.toFixed(1)),
      r.status,
      extraHours > 0 ? `+${extraHours.toFixed(1)}h` : "—",
      baseSalary.toLocaleString(),
      reduction > 0 ? `-${reduction.toLocaleString()}` : "—",
      netDay.toLocaleString(),
    ];
  });

  // Totals row
  const totalHours    = records.reduce((s, r) => s + (r.hoursWorked ?? 0), 0);
  const totalExtra    = records.reduce((s, r) => s + (r.extraHours  ?? 0), 0);
  const totalBase     = emp.salary || 0;  // monthly base (fixed)
  const totalReduction= records.reduce((s, r) => {
    return s + r2(Math.max(0, 8 - (r.hoursWorked??0)) * hourlyRate);
  }, 0);
  const totalNet      = r2(totalHours * hourlyRate) - avTotal;

  tableBody.push([
    "TOTAL",
    "—",
    "—",
    totalHours.toFixed(1),
    "—",
    totalExtra > 0 ? `+${totalExtra.toFixed(1)}h` : "—",
    totalBase.toLocaleString(),
    `-${totalReduction.toLocaleString()}`,
    avTotal > 0 ? `-${avTotal.toLocaleString()} (avance)` : "—",
  ]);

  autoTable(doc, {
    startY: infoY + 26,
    head: [["Date", "Rate/h", "Base Hrs", "Hrs Worked", "Status", "Overtime", "Base (TND)", "Reduction", "Net (TND)"]],
    body: tableBody,
    styles: {
      font: "courier", fontSize: 7.5, cellPadding: 2.5,
      textColor: [229, 231, 235], fillColor: DARK,
      lineColor: [31, 41, 55], lineWidth: 0.2,
    },
    headStyles: {
      fillColor: [10, 15, 24], textColor: GREEN,
      fontStyle: "bold", fontSize: 7, halign: "left",
    },
    alternateRowStyles: { fillColor: [10, 15, 24] },
    columnStyles: {
      0: { cellWidth: 24 },
      1: { halign: "right", cellWidth: 18 },
      2: { halign: "right", cellWidth: 18 },
      3: { halign: "right", cellWidth: 20 },
      4: { cellWidth: 18 },
      5: { halign: "right", cellWidth: 20 },
      6: { halign: "right" },
      7: { halign: "right" },
      8: { halign: "right" },
    },
    margin: { left: 14, right: 14 },
    theme: "grid",
    didParseCell: (data) => {
      const val = String(data.cell.raw);
      if (data.section === "body") {
        const isLastRow = data.row.index === tableBody.length - 1;
        if (isLastRow) { data.cell.styles.fontStyle = "bold"; data.cell.styles.fillColor = [10, 25, 16]; }
        if (val.startsWith("-")) data.cell.styles.textColor = [248, 113, 113];
        else if (val.startsWith("+")) data.cell.styles.textColor = [129, 140, 248];
        else if (val === "Present") data.cell.styles.textColor = [52, 211, 153];
        else if (val === "Absent")  data.cell.styles.textColor = [248, 113, 113];
        else if (val === "Late")    data.cell.styles.textColor = [251, 146, 60];
      }
    },
  });

  const afterTable = (doc as any).lastAutoTable?.finalY ?? 160;

  // ── Summary box ───────────────────────────────────────────────────────────
  // Brut earned from actual hours
  const brutEarned      = r2(totalHours * hourlyRate);
  // CNSS — informational only, NOT deducted from agreed net
  const cnssEmpDisplay  = r2(brutEarned * 0.0967);   // 9.67%  employee share
  const cnssErDisplay   = r2(brutEarned * 0.2000);   // 20.00% employer share
  const cnssTotalDisplay= r2(brutEarned * 0.2967);   // 29.67% total
  // Net = agreed salary − avance only
  const agreedNetDisplay = emp.salary || 0;
  const netDisplay       = r2(agreedNetDisplay - avTotal);

  const netY = afterTable + 6;

  doc.setFillColor(10, 15, 24);
  doc.rect(14, netY, W - 28, 34, "F");
  doc.setDrawColor(31, 41, 55);
  doc.rect(14, netY, W - 28, 34);

  // Left column — brut & CNSS breakdown
  doc.setFontSize(7); doc.setFont("helvetica", "bold"); doc.setTextColor(...GRAY);
  doc.text("BRUT SALARY (incl. charges)",  20, netY + 6);
  doc.text("CNSS EMPLOYEE  9.67%",         20, netY + 13);
  doc.text("CNSS EMPLOYER  20.00%",        20, netY + 19);
  doc.text("TOTAL CNSS  29.67%",           20, netY + 25);
  doc.setFontSize(6.5); doc.setFont("helvetica", "italic");
  doc.text("(informational — not deducted from agreed net)", 20, netY + 31);

  doc.setFont("helvetica", "normal"); doc.setTextColor(229, 231, 235);
  doc.text(`${brutEarned.toLocaleString()} TND`,           W/2 - 10, netY + 6,  { align: "right" });
  doc.setTextColor(251, 146, 60);
  doc.text(`${cnssEmpDisplay.toLocaleString()} TND`,       W/2 - 10, netY + 13, { align: "right" });
  doc.text(`${cnssErDisplay.toLocaleString()} TND`,        W/2 - 10, netY + 19, { align: "right" });
  doc.setFont("helvetica", "bold");
  doc.text(`${cnssTotalDisplay.toLocaleString()} TND`,     W/2 - 10, netY + 25, { align: "right" });

  // Divider
  doc.setDrawColor(...GREEN);
  doc.line(W/2, netY + 1, W/2, netY + 33);

  // Right column — agreed salary, avance, net
  doc.setFont("helvetica", "bold"); doc.setTextColor(...GRAY);
  doc.text("AGREED SALARY",    W/2 + 6, netY + 6);
  if (avTotal > 0) doc.text("AVANCE DEDUCTION", W/2 + 6, netY + 15);
  doc.text("NET TO PAY",       W/2 + 6, netY + 25);

  doc.setFont("helvetica", "normal"); doc.setTextColor(229, 231, 235);
  doc.text(`${agreedNetDisplay.toLocaleString()} TND`, W - 16, netY + 6,  { align: "right" });
  if (avTotal > 0) {
    doc.setTextColor(248, 113, 113);
    doc.text(`-${avTotal.toLocaleString()} TND`,       W - 16, netY + 15, { align: "right" });
  }
  doc.setFontSize(13); doc.setFont("helvetica", "bold"); doc.setTextColor(...GREEN);
  doc.text(`${netDisplay.toLocaleString()} TND`,       W - 16, netY + 32, { align: "right" });

  // Footer
  doc.setFontSize(7); doc.setFont("helvetica", "normal"); doc.setTextColor(...GRAY);
  doc.text(
    `Pay Slip — EMM Hardware ERP  ·  ${periodLabel}  ·  Generated ${now.toLocaleDateString("en-GB")}`,
    W / 2, netY + 22, { align: "center" }
  );

  const fname = fromMonth === toMonth
    ? `Payslip_${emp.name.replace(/ /g,"_")}_${fromMonth}.pdf`
    : `Payslip_${emp.name.replace(/ /g,"_")}_${fromMonth}_to_${toMonth}.pdf`;
  doc.save(fname);
}

// ── Component ─────────────────────────────────────────────────────────────────
export default function HRPayroll() {
  const { t } = useLanguage();
  const [rows, setRows]           = useState<PayrollRow[]>([]);
  const [allAvances, setAllAvances] = useState<any[]>([]);
  const [attMap, setAttMap]       = useState<Record<string, AttSummary>>({});
  const [loading, setLoading]     = useState(true);
  const [search, setSearch]       = useState("");
  const [filterDept, setFilter]   = useState("all");

  // Payslip modal state
  const [showPayslip, setShowPayslip]         = useState(false);
  const [payslipRow, setPayslipRow]           = useState<PayrollRow | null>(null);
  const [payslipLoading, setPayslipLoading]   = useState(false);
  const [psFromMonth, setPsFromMonth]         = useState(new Date().toISOString().slice(0, 7));
  const [psToMonth, setPsToMonth]             = useState(new Date().toISOString().slice(0, 7));
  const [dailyRecords, setDailyRecords]       = useState<any[]>([]);
  const [dailyFetching, setDailyFetching]     = useState(false);

  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7));

  const card = "bg-white dark:bg-[#0d1117] border border-gray-200 dark:border-white/[0.06] rounded-2xl transition-colors duration-300";
  const gridCols = "2fr 1fr 0.85fr 0.95fr 0.8fr 0.8fr 1fr 0.85fr";

  useEffect(() => { fetchData(); }, [selectedMonth]);

  async function fetchData() {
    setLoading(true);
    try {
      const [empsRes, avancesRes, attSummary] = await Promise.all([
        hrService.getAllEmployees(true),
        avanceService.list(),
        dailyAttendanceService.summary(selectedMonth).catch(() => []),
      ]);
      const emps    = (Array.isArray(empsRes) ? empsRes : empsRes?.data ?? []).filter((e: any) => e.role === "EMPLOYEE");
      const avances = Array.isArray(avancesRes) ? avancesRes : (avancesRes?.data ?? []);
      const map: Record<string, AttSummary> = {};
      for (const s of (attSummary || [])) map[s.employeeId] = s;
      setAllAvances(avances);
      setAttMap(map);
      setRows(emps.map((e: any) => calcRow(e, avances, map[e._id])));
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  }

  function exportCSV() {
    const headers = ["Name","Department","Position","Base (TND)","Overtime","Absent Days","Absence Deduction","CNSS","Avances","Net (TND)","Status","Month"];
    const data = rows.map(r => [
      r.emp.name, r.emp.department, r.emp.position, r.base, r.overtime,
      r.absenceDays, -r.absenceDeduction, r.cnss, -r.avances,
      r.net, r.emp.status || "Active", monthLabel(selectedMonth),
    ]);
    const csv = [headers,...data].map(row => row.map(v => `"${v}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href=url; a.download=`payroll_${selectedMonth}.csv`; a.click();
    URL.revokeObjectURL(url);
  }

  // Fetch daily records for employee across a month range
  async function fetchDailyRecords(empId: string, from: string, to: string) {
    setDailyFetching(true);
    try {
      const months: string[] = [];
      const [fy, fm] = from.split("-").map(Number);
      const [ty, tm] = to.split("-").map(Number);
      let y = fy, m = fm;
      while (y < ty || (y === ty && m <= tm)) {
        months.push(`${y}-${String(m).padStart(2,"0")}`);
        m++; if (m > 12) { m = 1; y++; }
      }
      const results = await Promise.all(
        months.map(month => dailyAttendanceService.list({ month, employeeId: empId }).catch(() => []))
      );
      setDailyRecords(results.flat().sort((a, b) => a.date.localeCompare(b.date)));
    } finally { setDailyFetching(false); }
  }

  function openPayslip(row: PayrollRow) {
    setPayslipRow(row);
    const m = new Date().toISOString().slice(0,7);
    setPsFromMonth(m); setPsToMonth(m);
    setDailyRecords([]);
    setShowPayslip(true);
    fetchDailyRecords(row.emp._id, m, m);
  }

  function handleRangeChange(from: string, to: string) {
    if (!payslipRow) return;
    setPsFromMonth(from); setPsToMonth(to);
    fetchDailyRecords(payslipRow.emp._id, from, to);
  }

  async function handleDownloadPayslip() {
    if (!payslipRow) return;
    setPayslipLoading(true);
    try {
      const empAvances = allAvances.filter((a: any) =>
        a.employeeId === payslipRow.emp._id &&
        (a.status === "Deducted" || a.status === "approved" || a.approved)
      );
      await downloadPayslipPDF(payslipRow.emp, dailyRecords, empAvances, psFromMonth, psToMonth);
    } finally { setPayslipLoading(false); }
  }

  const departments = ["all", ...Array.from(new Set(rows.map(r => r.emp.department).filter(Boolean)))];
  const filtered    = rows.filter(r => {
    const matchSearch = r.emp.name.toLowerCase().includes(search.toLowerCase());
    const matchDept   = filterDept === "all" || r.emp.department === filterDept;
    return matchSearch && matchDept;
  });

  const totalNet     = rows.reduce((s, r) => s + r.net,     0);
  const totalBase    = rows.reduce((s, r) => s + r.base,    0);
  const totalAvances = rows.reduce((s, r) => s + r.avances, 0);
  const onLeave      = rows.filter(r => r.emp.status === "On Leave").length;

  // Payslip preview calc

  return (
    <ProtectedRoute allowedRoles={["HR_MANAGER"]}>

      {/* Pay Slip Modal — outside DashboardLayout */}

      {/* Pay Slip Modal — outside DashboardLayout */}
      <AnimatePresence>
        {showPayslip && payslipRow && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/80 backdrop-blur-sm p-6"
            onClick={() => setShowPayslip(false)}>
            <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
              onClick={e => e.stopPropagation()}
              className="bg-white dark:bg-[#0d1117] border border-gray-200 dark:border-white/10 rounded-2xl w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">

              {/* Header */}
              <div className="flex items-center justify-between px-6 py-4 border-b border-white/[0.08] flex-shrink-0">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/10 flex items-center justify-center">
                    <Receipt size={15} className="text-emerald-400" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-white">{payslipRow.emp.name} — Pay Slip</h2>
                    <p className="text-[10px] text-gray-400">{payslipRow.emp.position} · {payslipRow.emp.department}</p>
                  </div>
                </div>
                <button onClick={() => setShowPayslip(false)} className="text-gray-500 hover:text-white transition"><X size={18} /></button>
              </div>

              {/* Date range picker */}
              <div className="flex items-center gap-4 px-6 py-3 border-b border-white/[0.06] flex-shrink-0 bg-white/[0.02]">
                <span className="text-[10px] uppercase tracking-widest text-gray-500">Period</span>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-400">From</span>
                  <input type="month" value={psFromMonth}
                    style={{ colorScheme: "dark" }}
                    onChange={e => handleRangeChange(e.target.value, psToMonth)}
                    className="bg-gray-100 dark:bg-black/30 border border-gray-200 dark:border-white/10 rounded-lg px-2 py-1 text-xs text-gray-900 dark:text-white focus:outline-none focus:border-emerald-500/50 transition" />
                  <span className="text-xs text-gray-400">To</span>
                  <input type="month" value={psToMonth}
                    style={{ colorScheme: "dark" }}
                    onChange={e => handleRangeChange(psFromMonth, e.target.value)}
                    className="bg-gray-100 dark:bg-black/30 border border-gray-200 dark:border-white/10 rounded-lg px-2 py-1 text-xs text-gray-900 dark:text-white focus:outline-none focus:border-emerald-500/50 transition" />
                </div>
                {/* Quick presets */}
                <div className="flex items-center gap-1.5 ml-auto">
                  {[
                    { label: "This month", fn: () => { const m = new Date().toISOString().slice(0,7); handleRangeChange(m,m); }},
                    { label: "Last 3M",    fn: () => { const now=new Date(); const to=now.toISOString().slice(0,7); now.setMonth(now.getMonth()-2); handleRangeChange(now.toISOString().slice(0,7),to); }},
                    { label: "This year",  fn: () => { const y=new Date().getFullYear(); handleRangeChange(`${y}-01`,`${y}-12`); }},
                  ].map((p,i) => (
                    <button key={i} onClick={p.fn}
                      className="px-2 py-1 rounded-lg text-[10px] border border-white/10 text-gray-400 hover:border-emerald-500/40 hover:text-emerald-400 transition">
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Scrollable daily records table */}
              <div className="overflow-y-auto flex-1 p-4 font-mono text-xs">
                {/* Salary missing warning */}
                {payslipRow.emp.salary === 0 && (
                  <div className="mx-4 mt-3 px-4 py-2.5 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs text-amber-400 flex items-center gap-2">
                    <span className="text-base">⚠️</span>
                    <span><strong>{payslipRow.emp.name}</strong> has no salary set. Go to Employees → Edit to set their salary first.</span>
                  </div>
                )}
                {dailyFetching ? (
                  <div className="flex items-center justify-center py-12 gap-2 text-gray-400">
                    <Loader2 size={16} className="animate-spin" /> Loading records…
                  </div>
                ) : dailyRecords.length === 0 ? (
                  <div className="py-12 text-center text-gray-500">
                    <p>No attendance records for this period.</p>
                    <p className="text-[10px] mt-1 text-gray-600">Make sure attendance is recorded for the selected months.</p>
                  </div>
                ) : (() => {
                  const salary = payslipRow.emp.salary || 0;
                  const hourlyRate = salary / 208;
                  const empAvances = allAvances.filter((a: any) =>
                    a.employeeId === payslipRow.emp._id &&
                    (a.status === "Deducted" || a.status === "approved" || a.approved)
                  );
                  const avTotal = empAvances.reduce((s: number, a: any) => s + (a.amount||0), 0);

                  let totalHours = 0, totalExtra = 0, totalReduction = 0;
                  const baseSalaryMonthly = salary; // monthly base salary

                  const th = "px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-left border border-white/[0.08] bg-white/[0.06] text-gray-400";
                  const td = "px-3 py-2 text-xs border border-white/[0.06]";

                  return (
                    <table className="w-full border-collapse">
                      <thead><tr>
                        <th className={th}>Date</th>
                        <th className={`${th} text-right`}>Rate/h</th>
                        <th className={`${th} text-right`}>Base Hrs</th>
                        <th className={`${th} text-right`}>Hrs Worked</th>
                        <th className={th}>Status</th>
                        <th className={`${th} text-right`}>Overtime</th>
                        <th className={`${th} text-right`}>Base (TND)</th>
                        <th className={`${th} text-right`}>Reduction</th>
                        <th className={`${th} text-right`}>Net (TND)</th>
                      </tr></thead>
                      <tbody>
                        {dailyRecords.map((r, i) => {
                          const hw       = r.hoursWorked ?? 0;
                          const ex       = r.extraHours  ?? 0;
                          // reduction = missed hours × hourly rate
                          const reduction= r2(Math.max(0, 8 - hw) * hourlyRate);
                          // net = base salary minus what's deducted for missing hours
                          const netDay   = r2(hw * hourlyRate);
                          totalHours    += hw;
                          totalExtra    += ex;
                          totalReduction+= reduction;
                          const statusColor = r.status === "Present" ? "text-emerald-400" : r.status === "Absent" ? "text-red-400" : "text-amber-400";
                          return (
                            <tr key={r._id} className={i % 2 === 0 ? "bg-white/[0.02]" : ""}>
                              <td className={`${td} text-gray-300`}>{r.date}</td>
                              <td className={`${td} text-right text-gray-400`}>{hourlyRate.toFixed(2)}</td>
                              <td className={`${td} text-right text-gray-400`}>208</td>
                              <td className={`${td} text-right text-white font-bold`}>{hw.toFixed(1)}</td>
                              <td className={`${td} ${statusColor} font-bold`}>{r.status}</td>
                              <td className={`${td} text-right ${ex > 0 ? "text-indigo-400" : "text-gray-600"}`}>
                                {ex > 0 ? `+${ex.toFixed(1)}h` : "—"}
                              </td>
                              <td className={`${td} text-right text-gray-300`}>{baseSalaryMonthly.toLocaleString()}</td>
                              <td className={`${td} text-right ${reduction > 0 ? "text-red-400" : "text-gray-600"}`}>
                                {reduction > 0 ? `-${reduction.toLocaleString()}` : "—"}
                              </td>
                              <td className={`${td} text-right font-bold ${netDay >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                                {netDay % 1 !== 0 ? netDay.toFixed(3) : netDay.toLocaleString()}
                              </td>
                            </tr>
                          );
                        })}

                        {/* Totals row */}
                        <tr className="bg-white/[0.06] border-t-2 border-emerald-500/30">
                          <td className={`${td} font-bold text-white`} colSpan={3}>TOTAL ({dailyRecords.length} days)</td>
                          <td className={`${td} text-right font-bold text-white`}>{totalHours.toFixed(1)}</td>
                          <td className={td}></td>
                          <td className={`${td} text-right text-indigo-400 font-bold`}>
                            {totalExtra > 0 ? `+${totalExtra.toFixed(1)}h` : "—"}
                          </td>
                          <td className={`${td} text-right font-bold text-white`}>
                            {baseSalaryMonthly.toLocaleString()}
                          </td>
                          <td className={`${td} text-right ${totalReduction > 0 ? "text-red-400 font-bold" : "text-gray-600"}`}>
                            {totalReduction > 0 ? `-${totalReduction.toLocaleString()}` : "—"}
                          </td>
                          <td className={`${td} text-right font-bold text-emerald-400`}>
                            {(r2(totalHours * hourlyRate) - avTotal).toLocaleString()}
                          </td>
                        </tr>

                        {/* Avances row */}
                        {avTotal > 0 && (
                          <tr className="bg-amber-500/5">
                            <td className={`${td} text-amber-400`} colSpan={8}>
                              Advance deductions ({empAvances.length} advance{empAvances.length > 1 ? "s" : ""})
                            </td>
                            <td className={`${td} text-right text-amber-400 font-bold`}>-{avTotal.toLocaleString()}</td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  );
                })()}
              </div>

              {/* Footer buttons */}
              <div className="flex gap-3 px-6 py-4 border-t border-white/[0.08] flex-shrink-0">
                <button onClick={handleDownloadPayslip} disabled={payslipLoading || dailyFetching || dailyRecords.length === 0}
                  className="flex-1 flex items-center justify-center gap-2 py-2 rounded-xl text-xs bg-emerald-500 hover:bg-emerald-400 text-black font-bold transition disabled:opacity-50">
                  {payslipLoading ? <Loader2 size={12} className="animate-spin" /> : <Download size={12} />}
                  Download PDF
                </button>
                <button onClick={() => setShowPayslip(false)}
                  className="flex-1 py-2 rounded-xl text-xs border border-white/10 text-gray-400 hover:border-white/20 hover:text-white transition">
                  Close
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      
        <div className="min-h-screen bg-gray-100 dark:bg-[#060a0f] text-gray-900 dark:text-white font-mono p-6 space-y-6">

          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold tracking-tight leading-none">
                Payroll <span className="text-emerald-400">Management</span>
              </h1>
              <p className="text-xs text-gray-500 mt-1.5 uppercase tracking-widest">EMM ERP · {monthLabel(selectedMonth)}</p>
            </div>
            <div className="flex items-center gap-3">
              <input type="month" value={selectedMonth} onChange={e => setSelectedMonth(e.target.value)}
                style={{ colorScheme: "dark" }}
                className="bg-white dark:bg-[#0d1117] border border-gray-200 dark:border-white/10 rounded-xl px-3 py-2 text-xs text-gray-900 dark:text-white focus:outline-none transition" />
              <button onClick={fetchData} className="flex items-center gap-2 border border-gray-300 dark:border-white/10 hover:border-gray-400 dark:hover:border-white/20 px-4 py-2 rounded-xl text-xs uppercase tracking-wide transition text-gray-600 dark:text-gray-300">
                <Loader2 size={13} className={loading ? "animate-spin" : ""} /> Refresh
              </button>
              <button onClick={exportCSV} className="flex items-center gap-2 border border-gray-300 dark:border-white/10 hover:border-gray-400 dark:hover:border-white/20 px-4 py-2 rounded-xl text-xs uppercase tracking-wide transition text-gray-600 dark:text-gray-300">
                <Download size={13} /> {t("export")}
              </button>
            </div>
          </div>

          {/* KPI strip */}
          <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
            {[
              { label: "Total Net Payroll", value: loading ? "—" : `${totalNet.toLocaleString()} TND`,    sub: monthLabel(selectedMonth),                  icon: <DollarSign size={14} />, iconBg: "bg-emerald-500/10 text-emerald-400" },
              { label: "Total Base Salary", value: loading ? "—" : `${totalBase.toLocaleString()} TND`,   sub: "Before deductions",           icon: <TrendingUp size={14} />, iconBg: "bg-blue-500/10 text-blue-400" },
              { label: "Avance Deductions", value: loading ? "—" : `${totalAvances.toLocaleString()} TND`,sub: "This month",                  icon: <FileText size={14} />,   iconBg: "bg-amber-500/10 text-amber-400" },
              { label: "On Leave",          value: loading ? "—" : String(onLeave),                       sub: `of ${rows.length} employees`, icon: <AlertCircle size={14} />,iconBg: "bg-purple-500/10 text-purple-400" },
            ].map((s, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}
                className={`${card} px-5 py-4 flex items-center gap-4`}>
                <div className={`p-2 rounded-xl ${s.iconBg}`}>{s.icon}</div>
                <div>
                  <p className="text-[10px] uppercase tracking-widest text-gray-500 mb-0.5">{s.label}</p>
                  <p className="text-xl font-bold tracking-tight">{s.value}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{s.sub}</p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Table */}
          <div className={`${card} overflow-hidden`}>
            <div className="flex items-center justify-between px-6 py-5 border-b border-gray-200 dark:border-white/[0.05]">
              <div>
                <h2 className="text-base font-bold">{t("payrollRecords")}</h2>
                <p className="text-xs text-gray-500">{filtered.length} {t("ofText")} {rows.length} employees · click a row to view pay slip</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Search size={12} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    className="pl-8 pr-3 py-1.5 bg-gray-100 dark:bg-black/30 border border-gray-200 dark:border-white/10 rounded-lg text-xs focus:outline-none focus:border-emerald-500/40 transition text-gray-900 dark:text-white placeholder-gray-400"
                    placeholder={t("searchEmployee")} value={search} onChange={e => setSearch(e.target.value)} />
                </div>
                <select
                  className="px-3 py-1.5 bg-gray-100 dark:bg-black/30 border border-gray-200 dark:border-white/10 rounded-lg text-xs text-gray-600 dark:text-gray-300 focus:outline-none transition"
                  value={filterDept} onChange={e => setFilter(e.target.value)}>
                  {departments.map(d => <option key={d} value={d}>{d === "all" ? "All Departments" : d}</option>)}
                </select>
              </div>
            </div>

            {/* Col headers */}
            <div className="grid px-6 py-3 text-[10px] uppercase tracking-widest text-gray-500 dark:text-gray-600 border-b border-gray-100 dark:border-white/[0.04]"
              style={{ gridTemplateColumns: gridCols }}>
              <span>Employee</span>
              <span>Brut (TND)</span>
              <span className="text-indigo-400">Overtime</span>
              <span className="text-red-400">Absence</span>
              <span>CNSS 29.67%</span>
              <span>Avance</span>
              <span>Net (TND)</span>
              <span>Status</span>
            </div>

            {loading ? (
              <div className="flex items-center justify-center py-12 text-gray-400 gap-2">
                <Loader2 size={16} className="animate-spin" /> Loading payroll...
              </div>
            ) : filtered.length === 0 ? (
              <div className="py-12 text-center text-xs text-gray-400">{t("noPayrollMatch")}</div>
            ) : filtered.map((row, i) => {
              const sc = STATUS_STYLES[row.emp.status] ?? STATUS_STYLES["Active"];
              return (
                <motion.div key={row.emp._id}
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                  onClick={() => openPayslip(row)}
                  className={`grid px-6 py-4 items-center cursor-pointer hover:bg-gray-50 dark:hover:bg-white/[0.03] transition ${i < filtered.length - 1 ? "border-b border-gray-100 dark:border-white/[0.03]" : ""}`}
                  style={{ gridTemplateColumns: gridCols }}>

                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${AVATAR_COLORS[i % AVATAR_COLORS.length]}`}>
                      {row.emp.name.split(" ").map(n => n[0]).join("").slice(0,2).toUpperCase()}
                    </div>
                    <div>
                      <p className="text-sm font-bold">{row.emp.name}</p>
                      <p className="text-[10px] text-gray-400">{row.emp.department}</p>
                    </div>
                  </div>

                  <p className="text-xs text-gray-600 dark:text-gray-300">{row.base.toLocaleString()}</p>

                  <p className={`text-xs font-bold ${row.overtime > 0 ? "text-indigo-400" : "text-gray-500 dark:text-gray-600"}`}>
                    {row.overtime > 0 ? `+${row.overtime.toLocaleString()}` : "—"}
                  </p>

                  <div>
                    {row.absenceDays > 0 ? (
                      <div className="flex flex-col gap-0.5">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-500/10 text-red-400 w-fit">{row.absenceDays}d</span>
                        <span className="text-[10px] text-red-400/70">-{row.absenceDeduction.toLocaleString()} TND</span>
                      </div>
                    ) : <span className="text-xs text-gray-500 dark:text-gray-600">—</span>}
                  </div>

                  <div>
                    <p className="text-xs text-gray-400 dark:text-gray-500">{row.cnssTotal.toLocaleString()}</p>
                    <p className="text-[10px] text-gray-500">29.67%</p>
                  </div>

                  <p className={`text-xs font-bold ${row.avances > 0 ? "text-amber-400" : "text-gray-500 dark:text-gray-600"}`}>
                    {row.avances > 0 ? `-${row.avances.toLocaleString()}` : "—"}
                  </p>

                  <p className={`text-sm font-bold ${row.net >= 0 ? "text-[#c8202f]" : "text-red-400"}`}>
                    {row.net.toLocaleString()} TND
                  </p>

                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold w-fit ${sc.badge}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />{row.emp.status}
                  </span>
                </motion.div>
              );
            })}
          </div>

        </div>
      
    </ProtectedRoute>
  );
}