"use client";

import ProtectedRoute from "@/components/ProtectedRoute";
import { useLanguage } from "@/context/LanguageContext";
import api from "@/services/api";
import { useEffect, useMemo, useState } from "react";
import { FileText, Loader2, Users, AlertTriangle, CheckCircle, Clock, Megaphone, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface SupplierPayable {
  _id: string; type: "SUPPLIER";
  invoiceNo: string; supplierId: string; supplierNo: string; supplierName: string;
  status: "APPROVED" | "PARTIALLY_PAID" | "PAID";
  totalTtc: number; amountPaid: number; creditNoteAmount: number; outstanding: number;
  legalizationStatus?: string; dueDate: string | null; invoiceDate: string | null;
  matchingStatus: string; isOverdue: boolean;
}
interface PayrollPayable {
  _id: string; type: "PAYROLL";
  invoiceNo: string; supplierName: string;
  status: "PAID" | "APPROVED" | "PENDING";
  totalTtc: number; amountPaid: number; outstanding: number;
  dueDate: string | null; invoiceDate: string | null; isOverdue: boolean;
  employeeCount: number; totalExpected: number; totalCNSS: number;
  totalAvances: number; committed: boolean; committedAt: string | null;
}
interface BudgetRequestPayable {
  _id: string; type: "BUDGET_REQUEST";
  invoiceNo: string; supplierName: string; status: "PENDING";
  totalTtc: number; amountPaid: number; outstanding: number;
  dueDate: string | null; invoiceDate: string | null; isOverdue: boolean;
  eventId: string; eventTitle: string; monthKey: string;
  requestNote: string; requestAmount: number;
}
type Payable = SupplierPayable | PayrollPayable | BudgetRequestPayable;

function fmt(n: number) {
  return n.toLocaleString("fr-TN", { minimumFractionDigits: 3, maximumFractionDigits: 3 });
}

export default function FinancePayablesPage() {
  const { language } = useLanguage();
  const isFr = language === "fr";

  const [items, setItems]           = useState<Payable[]>([]);
  const [loading, setLoading]       = useState(true);
  const [error, setError]           = useState("");
  const [committing, setCommitting] = useState(false);
  const [paying, setPaying]         = useState(false);
  const [reviewItem, setReviewItem] = useState<BudgetRequestPayable | null>(null);
  const [reviewNote, setReviewNote] = useState("");
  const [reviewing, setReviewing]   = useState(false);

  const load = async () => {
    try {
      setLoading(true); setError("");
      const res = await api.get("/finance/payables");
      setItems(res.data?.data ?? res.data ?? []);
    } catch (e: any) {
      setError(e.response?.data?.message || "Failed to load payables");
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const payrollItem    = items.find(i => i.type === "PAYROLL") as PayrollPayable | undefined;
  const budgetRequests = items.filter(i => i.type === "BUDGET_REQUEST") as BudgetRequestPayable[];
  const supplierItems  = items.filter(i => i.type === "SUPPLIER") as SupplierPayable[];
  const month = payrollItem?._id?.replace("payroll-", "") || new Date().toISOString().slice(0, 7);

  const handleCommit   = async () => {
    try { setCommitting(true); await api.post("/finance/payroll/commit", { month }); await load(); }
    catch (e: any) { setError(e.response?.data?.message || "Failed"); } finally { setCommitting(false); }
  };
  const handleMarkPaid = async () => {
    try { setPaying(true); await api.post("/finance/payroll/mark-paid", { month }); await load(); }
    catch (e: any) { setError(e.response?.data?.message || "Failed"); } finally { setPaying(false); }
  };
  const handleApprove  = async () => {
    if (!reviewItem) return;
    try {
      setReviewing(true);
      await api.patch(`/marketing/events/${reviewItem.eventId}/approve-budget`, { reviewNote });
      setReviewItem(null); setReviewNote(""); await load();
    } catch (e: any) { setError(e.response?.data?.message || "Failed"); } finally { setReviewing(false); }
  };
  const handleReject   = async () => {
    if (!reviewItem) return;
    try {
      setReviewing(true);
      await api.patch(`/marketing/events/${reviewItem.eventId}/reject-budget`, { reviewNote });
      setReviewItem(null); setReviewNote(""); await load();
    } catch (e: any) { setError(e.response?.data?.message || "Failed"); } finally { setReviewing(false); }
  };

  const totals = useMemo(() => ({
    outstanding: items.reduce((s, i) => s + i.outstanding, 0),
    paid:        items.reduce((s, i) => s + i.amountPaid,  0),
    overdue:     items.filter(i => i.isOverdue).length,
  }), [items]);

  const card     = "bg-white dark:bg-[#111c35] border border-gray-200 dark:border-[#1b2a6b]/20 rounded-2xl transition-colors duration-300";
  const inputCls = "w-full px-3 py-2 bg-gray-100 dark:bg-black/30 border border-gray-200 dark:border-white/10 rounded-xl text-sm text-gray-900 dark:text-white focus:outline-none focus:border-[#c8202f]/60 transition";
  const labelCls = "text-xs text-gray-500 uppercase tracking-widest mb-1 block";

  return (
    <ProtectedRoute allowedRoles={["ADMIN", "FINANCE_MANAGER"]}>
      <div className="min-h-screen bg-gray-100 dark:bg-[#060d1f] text-gray-900 dark:text-white font-mono p-6 space-y-6 transition-colors duration-300">

        <div>
          <h1 className="text-3xl font-bold tracking-tight leading-none">
            Finance <span className="text-[#c8202f]">{isFr ? "Dettes" : "Payables"}</span>
          </h1>
          <p className="text-xs text-gray-500 mt-1.5 uppercase tracking-widest">
            {isFr ? "Fournisseurs · Paie · Budget Marketing · EMM ERP" : "Suppliers · Payroll · Marketing Budget · EMM ERP"}
          </p>
        </div>

        {error && (
          <div className="text-red-400 text-xs bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-3">{error}</div>
        )}

        {loading ? (
          <div className="flex items-center justify-center py-20 gap-2 text-gray-400">
            <Loader2 size={18} className="animate-spin" />
            {isFr ? "Chargement…" : "Loading payables…"}
          </div>
        ) : (
          <>
            {/* ── KPI cards ── */}
            <div className="grid gap-4 md:grid-cols-3">
              {[
                { label: isFr ? "Restant dû" : "Outstanding", value: `${fmt(totals.outstanding)} TND`, color: "text-gray-900 dark:text-white" },
                { label: isFr ? "Payé"        : "Paid",        value: `${fmt(totals.paid)} TND`,        color: "text-[#c8202f]" },
                { label: isFr ? "En retard"   : "Overdue",     value: String(totals.overdue),            color: totals.overdue > 0 ? "text-red-400" : "text-gray-400" },
              ].map(({ label, value, color }) => (
                <div key={label} className={`${card} p-5`}>
                  <p className="text-[10px] uppercase tracking-widest text-gray-500 mb-2">{label}</p>
                  <p className={`text-2xl font-bold tracking-tight ${color}`}>{value}</p>
                </div>
              ))}
            </div>

            {/* ── Marketing Budget Requests ── */}
            {budgetRequests.length > 0 && (
              <div className={`${card} overflow-hidden`}>
                <div className="px-6 py-4 border-b border-gray-100 dark:border-white/[0.05] flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-purple-500/10"><Megaphone size={14} className="text-purple-400" /></div>
                  <div>
                    <p className="text-sm font-bold">{isFr ? "Demandes Budget Marketing" : "Marketing Budget Requests"}</p>
                    <p className="text-xs text-gray-500">{budgetRequests.length} {isFr ? "demande(s) en attente" : "pending request(s)"}</p>
                  </div>
                </div>
                <div className="divide-y divide-gray-100 dark:divide-white/[0.04]">
                  {budgetRequests.map(req => (
                    <div key={req._id} className="flex items-center gap-4 px-6 py-4 hover:bg-gray-50 dark:hover:bg-white/[0.02] transition">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-bold truncate">{req.eventTitle}</p>
                        <p className="text-xs text-gray-500">{req.monthKey}{req.requestNote ? ` · ${req.requestNote}` : ""}</p>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <p className="text-sm font-bold text-purple-400">{fmt(req.requestAmount)} TND</p>
                        <p className="text-[10px] text-gray-500">{isFr ? "demandé" : "requested"}</p>
                      </div>
                      <button
                        onClick={() => { setReviewItem(req); setReviewNote(""); }}
                        className="flex-shrink-0 px-3 py-1.5 rounded-xl bg-[#c8202f]/10 border border-[#c8202f]/30 text-[#c8202f] text-xs font-bold hover:bg-[#c8202f]/20 transition"
                      >
                        {isFr ? "Réviser" : "Review"}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ── Payroll ── */}
            {payrollItem && (
              <div className={`${card} overflow-hidden`}>
                <div className="px-6 py-4 border-b border-gray-100 dark:border-white/[0.05] flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-xl bg-[#c8202f]/10"><Users size={14} className="text-[#c8202f]" /></div>
                    <div>
                      <p className="text-sm font-bold">{isFr ? "Paie du mois" : "Monthly Payroll"} — {month}</p>
                      <p className="text-xs text-gray-500">{payrollItem.employeeCount} {isFr ? "employés" : "employees"}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {payrollItem.status === "PAID" ? (
                      <span className="flex items-center gap-1.5 text-[10px] font-bold px-2.5 py-1 rounded-full bg-[#c8202f]/15 text-[#c8202f]">
                        <CheckCircle size={10} /> {isFr ? "Payé" : "Paid"}
                      </span>
                    ) : payrollItem.committed ? (
                      <span className="flex items-center gap-1.5 text-[10px] font-bold px-2.5 py-1 rounded-full bg-amber-500/15 text-amber-400">
                        <Clock size={10} /> {isFr ? "En attente" : "Awaiting Payment"}
                      </span>
                    ) : (
                      <span className="flex items-center gap-1.5 text-[10px] font-bold px-2.5 py-1 rounded-full bg-gray-500/15 text-gray-400">
                        <AlertTriangle size={10} /> {isFr ? "Non engagé" : "Not Committed"}
                      </span>
                    )}
                    {!payrollItem.committed && (
                      <button onClick={handleCommit} disabled={committing}
                        className="flex items-center gap-2 bg-[#c8202f] hover:bg-[#e02d3c] px-3 py-1.5 rounded-xl text-xs font-bold text-black transition disabled:opacity-50">
                        {committing && <Loader2 size={11} className="animate-spin" />}
                        {isFr ? "Engager" : "Commit"}
                      </button>
                    )}
                    {payrollItem.committed && payrollItem.status !== "PAID" && (
                      <button onClick={handleMarkPaid} disabled={paying}
                        className="flex items-center gap-2 bg-blue-500 hover:bg-blue-400 px-3 py-1.5 rounded-xl text-xs font-bold text-white transition disabled:opacity-50">
                        {paying && <Loader2 size={11} className="animate-spin" />}
                        {isFr ? "Marquer payé" : "Mark Paid"}
                      </button>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-gray-100 dark:divide-white/[0.04]">
                  {[
                    { label: isFr ? "Salaires bruts" : "Gross Salaries",     value: `${fmt(payrollItem.totalExpected)} TND`, color: "text-gray-900 dark:text-white" },
                    { label: "CNSS",                                           value: `-${fmt(payrollItem.totalCNSS)} TND`,    color: "text-amber-500" },
                    { label: isFr ? "Avances déduites" : "Avance Deductions", value: `-${fmt(payrollItem.totalAvances)} TND`, color: "text-red-400" },
                    { label: isFr ? "Net à payer" : "Net to Pay",              value: `${fmt(payrollItem.outstanding || payrollItem.totalTtc)} TND`, color: "text-[#c8202f] font-bold" },
                  ].map(({ label, value, color }) => (
                    <div key={label} className="px-6 py-4">
                      <p className="text-[10px] uppercase tracking-widest text-gray-500 mb-1">{label}</p>
                      <p className={`text-base font-bold ${color}`}>{value}</p>
                    </div>
                  ))}
                </div>
                {payrollItem.isOverdue && payrollItem.status !== "PAID" && (
                  <div className="px-6 py-3 bg-red-500/5 border-t border-red-500/20 text-xs text-red-400">
                    ⚠ {isFr ? "Paie en retard — le mois est terminé" : "Payroll overdue — month has ended"}
                  </div>
                )}
              </div>
            )}

            {/* ── Supplier invoices ── */}
            <div className={`${card} overflow-hidden`}>
              <div className="border-b border-gray-100 dark:border-white/[0.05] px-6 py-5">
                <h2 className="text-base font-bold">{isFr ? "Factures Fournisseurs" : "Supplier Invoices"}</h2>
                <p className="text-xs text-gray-500">{supplierItems.length} {isFr ? "factures" : "invoices"}</p>
              </div>
              {!supplierItems.length ? (
                <div className="flex flex-col items-center justify-center py-16">
                  <FileText size={32} className="mb-3 text-gray-300 dark:text-gray-700" />
                  <p className="text-sm text-gray-400">{isFr ? "Aucune dette fournisseur" : "No supplier payables yet"}</p>
                </div>
              ) : (
                <div className="divide-y divide-gray-100 dark:divide-white/[0.04]">
                  <div className="grid gap-3 px-6 py-3 text-[10px] uppercase tracking-widest text-gray-500 dark:text-gray-600"
                    style={{ gridTemplateColumns: "1.5fr 1fr 0.8fr 0.8fr 0.9fr" }}>
                    <span>{isFr ? "Facture" : "Invoice"}</span>
                    <span>{isFr ? "Statut" : "Status"}</span>
                    <span>{isFr ? "Date" : "Date"}</span>
                    <span>{isFr ? "Payé" : "Paid"}</span>
                    <span className="text-right">{isFr ? "Restant" : "Outstanding"}</span>
                  </div>
                  {supplierItems.map(item => (
                    <div key={item._id} className="grid gap-3 px-6 py-4 items-center hover:bg-gray-50 dark:hover:bg-white/[0.02] transition"
                      style={{ gridTemplateColumns: "1.5fr 1fr 0.8fr 0.8fr 0.9fr" }}>
                      <div>
                        <p className="text-sm font-bold">{item.invoiceNo}</p>
                        <p className="text-xs text-gray-500">{item.supplierName}{item.supplierNo ? ` (${item.supplierNo})` : ""}</p>
                      </div>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full w-fit ${
                        item.status === "PAID"           ? "bg-[#c8202f]/15 text-[#c8202f]" :
                        item.status === "PARTIALLY_PAID" ? "bg-amber-500/15 text-amber-400" :
                        "bg-gray-500/10 text-gray-400"
                      }`}>{item.status}</span>
                      <div className="text-xs text-gray-500">
                        <p>{item.invoiceDate ? new Date(item.invoiceDate).toLocaleDateString("fr-TN") : "—"}</p>
                        <p className={item.isOverdue ? "text-red-400" : "text-gray-400"}>
                          {isFr ? "Éch:" : "Due:"} {item.dueDate ? new Date(item.dueDate).toLocaleDateString("fr-TN") : "—"}
                        </p>
                      </div>
                      <p className="text-xs text-gray-500">{fmt(item.amountPaid)} TND</p>
                      <div className="text-right">
                        <p className="text-sm font-bold">{fmt(item.outstanding)} TND</p>
                        {item.isOverdue && <p className="text-[10px] text-red-400">{isFr ? "En retard" : "Overdue"}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        )}
      </div>

      {/* ── Budget Request Review Modal ── */}
      <AnimatePresence>
        {reviewItem && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
            <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-[#111c35] border border-gray-200 dark:border-white/10 rounded-2xl p-6 w-full max-w-sm shadow-2xl space-y-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-purple-500/10"><Megaphone size={16} className="text-purple-400" /></div>
                  <div>
                    <h3 className="text-base font-bold">Budget Request</h3>
                    <p className="text-xs text-gray-500 mt-0.5">{reviewItem.eventTitle}</p>
                  </div>
                </div>
                <button onClick={() => setReviewItem(null)} className="text-gray-400 hover:text-gray-600 dark:hover:text-white transition">
                  <X size={18} />
                </button>
              </div>

              <div className="bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/10 rounded-xl px-4 py-3 space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-gray-500">Month</span>
                  <span className="font-bold">{reviewItem.monthKey}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-500">Requested</span>
                  <span className="font-bold text-purple-400">{fmt(reviewItem.requestAmount)} TND</span>
                </div>
                {reviewItem.requestNote && (
                  <div className="pt-2 border-t border-gray-200 dark:border-white/10">
                    <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-0.5">Note</p>
                    <p className="text-xs text-gray-700 dark:text-gray-300">{reviewItem.requestNote}</p>
                  </div>
                )}
              </div>

              <div>
                <label className={labelCls}>Review Note (optional)</label>
                <textarea rows={2} value={reviewNote} onChange={e => setReviewNote(e.target.value)}
                  placeholder="e.g. Approved for Q2 campaign expansion..."
                  className={`${inputCls} resize-none`} />
              </div>

              <div className="flex gap-3">
                <button onClick={handleReject} disabled={reviewing}
                  className="flex-1 py-2.5 rounded-xl text-xs font-bold border border-red-500/30 text-red-400 bg-red-500/10 hover:bg-red-500/20 transition disabled:opacity-50 flex items-center justify-center gap-2">
                  {reviewing && <Loader2 size={12} className="animate-spin" />}
                  {isFr ? "Rejeter" : "Reject"}
                </button>
                <button onClick={handleApprove} disabled={reviewing}
                  className="flex-1 py-2.5 rounded-xl text-xs font-bold bg-[#c8202f] hover:bg-[#e02d3c] text-black transition disabled:opacity-50 flex items-center justify-center gap-2">
                  {reviewing && <Loader2 size={12} className="animate-spin" />}
                  {isFr ? "Approuver" : "Approve"}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </ProtectedRoute>
  );
}