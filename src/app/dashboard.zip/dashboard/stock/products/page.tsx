// Stock — Products
"use client";

import ProtectedRoute from "@/components/ProtectedRoute";
import { useLanguage } from "@/context/LanguageContext";
import { motion, AnimatePresence } from "framer-motion";
import { Package, Search, Plus, Pencil, Trash2, X, Loader2, Boxes, ScanLine, Tag } from "lucide-react";
import { useEffect, useState } from "react";
import { stockProductService, StockProduct } from "@/services/stock/stockProductService";
import { skuSettingService } from "@/services/stock/skuSettingService";

// StockProduct type imported from stockProductService
interface SkuSetting { _id: string; skuName: string; skuMax: number; }
interface ProductFormState {
  skuPrefix: string; name: string; type: StockProduct["type"];
  unit: StockProduct["unit"]; isLotTracked: boolean; status: StockProduct["status"];
}

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white dark:bg-[#111c35] border border-gray-200 dark:border-white/10 rounded-2xl w-full max-w-lg p-6 shadow-2xl">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-base font-bold text-gray-900 dark:text-white">{title}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-white transition"><X size={18} /></button>
        </div>
        {children}
      </motion.div>
    </div>
  );
}

const AVATAR_COLORS = [
  "bg-[#c8202f]/20 text-[#c8202f]","bg-blue-500/20 text-blue-400",
  "bg-purple-500/20 text-purple-400","bg-amber-500/20 text-amber-400",
  "bg-pink-500/20 text-pink-400","bg-teal-500/20 text-teal-400",
  "bg-red-500/20 text-red-400","bg-indigo-500/20 text-indigo-400",
];

export default function StockProductsPage() {
  const { t } = useLanguage();
  const PRODUCT_TYPES: StockProduct["type"][] = ["PRODUIT_FINI","SOUS_ENSEMBLE","COMPOSANT","MATIERE_PREMIERE"];
  const PRODUCT_UNITS: StockProduct["unit"][] = ["pcs","kg","l","m"];

  const [skuSettings, setSkuSettings] = useState<SkuSetting[]>([]);
  const [products, setProducts]       = useState<StockProduct[]>([]);
  const [search, setSearch]           = useState("");
  const [typeFilter, setTypeFilter]   = useState<StockProduct["type"] | "ALL">("ALL");
  const [loading, setLoading]         = useState(true);
  const [submitting, setSubmitting]   = useState(false);
  const [showCreate, setShowCreate]   = useState(false);
  const [showEdit, setShowEdit]       = useState(false);
  const [showDelete, setShowDelete]   = useState(false);
  const [selected, setSelected]       = useState<StockProduct | null>(null);
  const [formError, setFormError]     = useState("");

  const emptyForm: ProductFormState = { skuPrefix: "", name: "", type: "PRODUIT_FINI", unit: "pcs", isLotTracked: false, status: "ACTIVE" };
  const [form, setForm] = useState<ProductFormState>(emptyForm);

  const card = "bg-white dark:bg-[#111c35] border border-[#1b2a6b]/15 dark:border-[#1b2a6b]/20 border-t-2 border-t-[#c8202f] rounded-2xl transition-colors duration-300 hover:shadow-[0_0_20px_#c8202f10]";
  const inputClass = "w-full px-3 py-2 bg-gray-100 dark:bg-black/30 border border-gray-200 dark:border-white/10 rounded-xl text-sm text-gray-900 dark:text-white focus:outline-none focus:border-[#c8202f]/60 transition";
  const labelClass = "text-xs text-gray-500 uppercase tracking-widest mb-1 block";

  const getNextNumber = (prefix: string) => {
    const setting = skuSettings.find(s => s.skuName === prefix);
    if (!setting) return "";
    let max = 0;
    for (const p of products) {
      if (p.sku.startsWith(prefix + "-")) {
        const n = p.sku.slice(prefix.length + 1);
        if (/^\d+$/.test(n)) max = Math.max(max, Number(n));
      }
    }
    return String(max + 1).padStart(setting.skuMax, "0");
  };
  const composeSku = (prefix: string) => {
    if (!prefix) return "";
    const next = getNextNumber(prefix);
    return next ? `${prefix}-${next}` : "";
  };

  useEffect(() => {
    skuSettingService.getAll().then(setSkuSettings).catch(() => {});
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    setLoading(true);
    try { setProducts(await stockProductService.getAll()); }
    catch (e: any) { console.error(e); }
    finally { setLoading(false); }
  };

  const filtered = products.filter(p => {
    const q = search.toLowerCase();
    const matchSearch = p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q) || p.type.toLowerCase().includes(q);
    return matchSearch && (typeFilter === "ALL" || p.type === typeFilter);
  });

  const activeCount    = products.filter(p => p.status === "ACTIVE").length;
  const lotTrackedCount = products.filter(p => p.isLotTracked).length;
  const typesCount     = new Set(products.map(p => p.type)).size;

  const TYPE_LABELS: Record<string, string> = {
    PRODUIT_FINI: "Produit Fini", SOUS_ENSEMBLE: "Sous-ensemble",
    COMPOSANT: "Composant", MATIERE_PREMIERE: "Matière Première",
  };

  const handleCreate = async () => {
    if (!form.name.trim()) { setFormError("Product name is required"); return; }
    try {
      setSubmitting(true); setFormError("");
      await stockProductService.create({ sku: composeSku(form.skuPrefix), name: form.name.trim(), type: form.type, unit: form.unit, isLotTracked: form.isLotTracked, status: form.status });
      await fetchProducts(); setShowCreate(false); setForm(emptyForm);
    } catch (e: any) { setFormError(e.response?.data?.message || "Failed to create product"); }
    finally { setSubmitting(false); }
  };

  const handleEdit = async () => {
    if (!selected || !form.name.trim()) { setFormError("Product name is required"); return; }
    try {
      setSubmitting(true); setFormError("");
      await stockProductService.update(selected._id, { sku: selected.sku, name: form.name.trim(), type: form.type, unit: form.unit, isLotTracked: form.isLotTracked, status: form.status });
      await fetchProducts(); setShowEdit(false); setSelected(null);
    } catch (e: any) { setFormError(e.response?.data?.message || "Failed to update product"); }
    finally { setSubmitting(false); }
  };

  const handleDelete = async () => {
    if (!selected) return;
    try {
      setSubmitting(true);
      await stockProductService.delete(selected._id);
      await fetchProducts(); setShowDelete(false); setSelected(null);
    } catch (e: any) { console.error(e); }
    finally { setSubmitting(false); }
  };

  return (
    <ProtectedRoute allowedRoles={["ADMIN", "STOCK_MANAGER"]}>
      <div className="min-h-screen bg-gray-100 dark:bg-[#060d1f] text-gray-900 dark:text-white font-mono p-6 space-y-6 transition-colors duration-300">

        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight leading-none">
              {t("products")} <span className="text-[#c8202f]">Stock</span>
            </h1>
            <p className="text-xs text-gray-500 mt-1.5 uppercase tracking-widest">EMM ERP</p>
          </div>
          <button onClick={() => { setForm({ ...emptyForm, skuPrefix: skuSettings[0]?.skuName ?? "" }); setFormError(""); setShowCreate(true); }}
            className="flex items-center gap-2 bg-[#c8202f] hover:bg-[#e02d3c] px-4 py-2 rounded-xl text-xs uppercase tracking-wide transition text-black font-bold">
            <Plus size={13} /> {t("addProduct")}
          </button>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[
            { label: t("totalProducts"), value: String(products.length), sub: `${activeCount} ${t("active")}`, icon: <Boxes size={16} />, iconBg: "bg-[#c8202f]/10 text-[#c8202f]", valueColor: "text-[#c8202f]" },
            { label: t("categories"),   value: String(typesCount),       sub: t("productTypes"),              icon: <Tag size={16} />,   iconBg: "bg-blue-500/10 text-blue-400",    valueColor: "text-blue-400"    },
            { label: t("lotTracking"),  value: String(lotTrackedCount),  sub: t("tracked"),                   icon: <ScanLine size={16} />, iconBg: "bg-amber-500/10 text-amber-400", valueColor: "text-amber-400" },
          ].map((kpi, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
              className={`${card} p-5 flex items-center gap-4`}>
              <div className={`p-3 rounded-xl ${kpi.iconBg}`}>{kpi.icon}</div>
              <div>
                <p className="text-[10px] uppercase tracking-widest text-gray-500">{kpi.label}</p>
                <p className={`text-3xl font-bold tracking-tight mt-1 ${kpi.valueColor}`}>{kpi.value}</p>
                <p className="text-xs text-gray-500 mt-0.5">{kpi.sub}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Table */}
        <div className={`${card} overflow-hidden`}>
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 px-6 py-5 border-b border-gray-100 dark:border-white/[0.05]">
            <div>
              <h2 className="text-base font-bold text-gray-900 dark:text-white">{t("products")}</h2>
              <p className="text-xs text-gray-500">{filtered.length} {t("ofText")} {products.length} {t("records")}</p>
            </div>
            <div className="flex items-center gap-3 flex-wrap">
              <div className="relative">
                <Search size={12} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <input className="pl-8 pr-3 py-1.5 bg-gray-100 dark:bg-black/30 border border-gray-300 dark:border-white/10 rounded-lg text-xs focus:outline-none focus:border-[#c8202f]/40 transition text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-600"
                  placeholder={t("searchProducts")} value={search} onChange={e => setSearch(e.target.value)} />
              </div>
              <select className="px-3 py-1.5 bg-gray-100 dark:bg-black/30 border border-gray-300 dark:border-white/10 rounded-lg text-xs text-gray-600 dark:text-gray-300 focus:outline-none focus:border-[#c8202f]/40 transition"
                value={typeFilter} onChange={e => setTypeFilter(e.target.value as StockProduct["type"] | "ALL")}>
                <option value="ALL">{t("allTypes")}</option>
                {PRODUCT_TYPES.map(type => <option key={type} value={type}>{TYPE_LABELS[type]}</option>)}
              </select>
            </div>
          </div>

          {/* Table header */}
          <div className="grid px-6 py-3 text-[10px] uppercase tracking-widest text-gray-500 dark:text-gray-600 border-b border-gray-100 dark:border-white/[0.04]"
            style={{ gridTemplateColumns: "1.2fr 2.5fr 1.5fr 0.8fr 0.8fr 0.8fr 100px" }}>
            <span>{t("sku")}</span><span>{t("product")}</span><span>Type</span>
            <span>{t("unit")}</span><span>{t("lotTracking")}</span><span>{t("status")}</span><span>Actions</span>
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-12 gap-2 text-gray-400"><Loader2 size={16} className="animate-spin" /> Loading…</div>
          ) : filtered.length === 0 ? (
            <div className="py-12 text-center text-xs text-gray-500 dark:text-gray-600">{t("noProductsMatch")}</div>
          ) : (
            filtered.map((product, i) => (
              <motion.div key={product._id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                className={`grid px-6 py-4 items-center hover:bg-gray-50 dark:hover:bg-white/[0.02] transition ${i < filtered.length - 1 ? "border-b border-gray-100 dark:border-white/[0.03]" : ""}`}
                style={{ gridTemplateColumns: "1.2fr 2.5fr 1.5fr 0.8fr 0.8fr 0.8fr 100px" }}>

                <p className="text-xs font-bold text-[#c8202f] font-mono">{product.sku}</p>

                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${AVATAR_COLORS[i % AVATAR_COLORS.length]}`}>
                    {product.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-gray-900 dark:text-white">{product.name}</p>
                    <p className="text-[10px] text-gray-400">{TYPE_LABELS[product.type]}</p>
                  </div>
                </div>

                <span className="text-xs text-gray-500 dark:text-gray-400">{TYPE_LABELS[product.type]}</span>
                <span className="text-xs text-gray-500 dark:text-gray-400">{product.unit}</span>

                <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold w-fit ${product.isLotTracked ? "bg-amber-500/15 text-amber-400" : "bg-gray-100 dark:bg-white/5 text-gray-500"}`}>
                  {product.isLotTracked ? "Yes" : "No"}
                </span>

                <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold w-fit ${product.status === "ACTIVE" ? "bg-[#c8202f]/15 text-[#c8202f]" : "bg-gray-100 dark:bg-white/5 text-gray-500"}`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${product.status === "ACTIVE" ? "bg-[#e02d3c]" : "bg-gray-400"}`} />
                  {product.status}
                </span>

                <div className="flex items-center gap-1.5">
                  <button onClick={() => { setSelected(product); setForm({ skuPrefix: "", name: product.name, type: product.type, unit: product.unit, isLotTracked: product.isLotTracked, status: product.status }); setFormError(""); setShowEdit(true); }}
                    className="p-1.5 rounded-lg text-blue-400 hover:bg-blue-500/10 transition"><Pencil size={13} /></button>
                  <button onClick={() => { setSelected(product); setShowDelete(true); }}
                    className="p-1.5 rounded-lg text-red-400 hover:bg-red-500/10 transition"><Trash2 size={13} /></button>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </div>

      <AnimatePresence>
        {showCreate && (
          <Modal title={t("addProduct")} onClose={() => setShowCreate(false)}>
            <div className="space-y-4">
              {skuSettings.length === 0 ? (
                <div className="px-4 py-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-400">
                  No SKU prefixes configured. Go to Stock → Settings to create one.
                </div>
              ) : (
                <div>
                  <label className={labelClass}>{t("sku")}</label>
                  <div className="flex items-center gap-3">
                    <select className={inputClass} value={form.skuPrefix} onChange={e => setForm(f => ({ ...f, skuPrefix: e.target.value }))}>
                      {skuSettings.map(s => <option key={s._id} value={s.skuName}>{s.skuName}</option>)}
                    </select>
                    {composeSku(form.skuPrefix) && (
                      <span className="px-3 py-2 rounded-xl bg-[#c8202f]/10 border border-[#c8202f]/20 text-xs font-bold text-[#c8202f] font-mono whitespace-nowrap">
                        {composeSku(form.skuPrefix)}
                      </span>
                    )}
                  </div>
                </div>
              )}
              <div>
                <label className={labelClass}>{t("product")}</label>
                <input className={inputClass} value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>Type</label>
                  <select className={inputClass} value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value as StockProduct["type"] }))}>
                    {PRODUCT_TYPES.map(t => <option key={t} value={t}>{TYPE_LABELS[t]}</option>)}
                  </select>
                </div>
                <div>
                  <label className={labelClass}>{t("unit")}</label>
                  <select className={inputClass} value={form.unit} onChange={e => setForm(f => ({ ...f, unit: e.target.value as StockProduct["unit"] }))}>
                    {PRODUCT_UNITS.map(u => <option key={u} value={u}>{u}</option>)}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>{t("status")}</label>
                  <select className={inputClass} value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value as "ACTIVE" | "INACTIVE" }))}>
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="INACTIVE">INACTIVE</option>
                  </select>
                </div>
                <div>
                  <label className={labelClass}>{t("lotTracking")}</label>
                  <select className={inputClass} value={form.isLotTracked ? "true" : "false"} onChange={e => setForm(f => ({ ...f, isLotTracked: e.target.value === "true" }))}>
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>
              </div>
              {formError && <p className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">{formError}</p>}
              <div className="flex gap-3 pt-2">
                <button onClick={() => setShowCreate(false)} className="flex-1 px-4 py-2 rounded-xl border border-gray-200 dark:border-white/10 text-xs text-gray-500 hover:text-gray-900 dark:hover:text-white transition">Cancel</button>
                <button onClick={handleCreate} disabled={submitting} className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-[#c8202f] hover:bg-[#e02d3c] text-black font-bold text-xs transition disabled:opacity-60">
                  {submitting ? <Loader2 size={13} className="animate-spin" /> : <Plus size={13} />} {t("addProduct")}
                </button>
              </div>
            </div>
          </Modal>
        )}

        {showEdit && selected && (
          <Modal title={t("editProduct")} onClose={() => setShowEdit(false)}>
            <div className="space-y-4">
              <div>
                <label className={labelClass}>{t("sku")}</label>
                <div className="px-3 py-2 rounded-xl bg-gray-100 dark:bg-white/5 text-xs font-bold text-[#c8202f] font-mono">{selected.sku}</div>
              </div>
              <div>
                <label className={labelClass}>{t("product")}</label>
                <input className={inputClass} value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>Type</label>
                  <select className={inputClass} value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value as StockProduct["type"] }))}>
                    {PRODUCT_TYPES.map(t => <option key={t} value={t}>{TYPE_LABELS[t]}</option>)}
                  </select>
                </div>
                <div>
                  <label className={labelClass}>{t("unit")}</label>
                  <select className={inputClass} value={form.unit} onChange={e => setForm(f => ({ ...f, unit: e.target.value as StockProduct["unit"] }))}>
                    {PRODUCT_UNITS.map(u => <option key={u} value={u}>{u}</option>)}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>{t("status")}</label>
                  <select className={inputClass} value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value as "ACTIVE" | "INACTIVE" }))}>
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="INACTIVE">INACTIVE</option>
                  </select>
                </div>
                <div>
                  <label className={labelClass}>{t("lotTracking")}</label>
                  <select className={inputClass} value={form.isLotTracked ? "true" : "false"} onChange={e => setForm(f => ({ ...f, isLotTracked: e.target.value === "true" }))}>
                    <option value="false">No</option>
                    <option value="true">Yes</option>
                  </select>
                </div>
              </div>
              {formError && <p className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">{formError}</p>}
              <div className="flex gap-3 pt-2">
                <button onClick={() => setShowEdit(false)} className="flex-1 px-4 py-2 rounded-xl border border-gray-200 dark:border-white/10 text-xs text-gray-500 hover:text-gray-900 dark:hover:text-white transition">Cancel</button>
                <button onClick={handleEdit} disabled={submitting} className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-blue-500 hover:bg-blue-400 text-white font-bold text-xs transition disabled:opacity-60">
                  {submitting ? <Loader2 size={13} className="animate-spin" /> : <Pencil size={13} />} {t("saveChanges")}
                </button>
              </div>
            </div>
          </Modal>
        )}

        {showDelete && selected && (
          <Modal title="Delete Product" onClose={() => setShowDelete(false)}>
            <div className="space-y-4">
              <p className="text-sm text-gray-500">Are you sure you want to delete <span className="font-bold text-gray-900 dark:text-white">{selected.name}</span>? This cannot be undone.</p>
              <div className="flex gap-3 pt-2">
                <button onClick={() => setShowDelete(false)} className="flex-1 px-4 py-2 rounded-xl border border-gray-200 dark:border-white/10 text-xs text-gray-500 hover:text-gray-900 dark:hover:text-white transition">Cancel</button>
                <button onClick={handleDelete} disabled={submitting} className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-red-500 hover:bg-red-400 text-white font-bold text-xs transition disabled:opacity-60">
                  {submitting ? <Loader2 size={13} className="animate-spin" /> : <Trash2 size={13} />} Delete
                </button>
              </div>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </ProtectedRoute>
  );
}