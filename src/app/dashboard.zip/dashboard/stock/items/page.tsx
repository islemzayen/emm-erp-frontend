// Stock — Items (Live State)
"use client";

import ProtectedRoute from "@/components/ProtectedRoute";
import { useLanguage } from "@/context/LanguageContext";
import { motion } from "framer-motion";
import { BarChart3, Boxes, Loader2, Package, Search, ChevronLeft, ChevronRight, RefreshCw } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { stockItemService } from "@/services/stock/stockItemService";

const PAGE_SIZE = 20;

interface StockProduct {
  _id: string; sku: string; name: string;
  type: "PRODUIT_FINI" | "SOUS_ENSEMBLE" | "COMPOSANT" | "MATIERE_PREMIERE";
  unit: string; status: "ACTIVE" | "INACTIVE";
}
interface StockItem {
  _id: string; productId: StockProduct;
  quantityOnHand: number; quantityReserved: number; quantityAvailable: number;
  lastMovementAt?: string | null; status: "ACTIVE" | "INACTIVE"; updatedAt: string;
}

const AVATAR_COLORS = [
  "bg-[#c8202f]/20 text-[#c8202f]","bg-blue-500/20 text-blue-400",
  "bg-purple-500/20 text-purple-400","bg-amber-500/20 text-amber-400",
  "bg-pink-500/20 text-pink-400","bg-teal-500/20 text-teal-400",
  "bg-red-500/20 text-red-400","bg-indigo-500/20 text-indigo-400",
];

export default function StockItemsPage() {
  const { t } = useLanguage();
  const [items, setItems]     = useState<StockItem[]>([]);
  const [search, setSearch]   = useState("");
  const [page, setPage]       = useState(1);
  const [loading, setLoading] = useState(true);

  const card = "bg-white dark:bg-[#111c35] border border-[#1b2a6b]/15 dark:border-[#1b2a6b]/20 border-t-2 border-t-[#c8202f] rounded-2xl transition-colors duration-300 hover:shadow-[0_0_20px_#c8202f10]";

  const fetchItems = async () => {
    setLoading(true);
    try { setItems(await stockItemService.getAll()); }
    catch (e: any) { console.error(e); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchItems(); }, []);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    if (!q) return items;
    return items.filter(item => {
      const p = item.productId;
      return p?.name?.toLowerCase().includes(q) || p?.sku?.toLowerCase().includes(q) || p?.type?.toLowerCase().includes(q);
    });
  }, [items, search]);

  const totals = useMemo(() => filtered.reduce((acc, item) => ({
    onHand:    acc.onHand    + (item.quantityOnHand    || 0),
    reserved:  acc.reserved  + (item.quantityReserved  || 0),
    available: acc.available + (item.quantityAvailable || 0),
  }), { onHand: 0, reserved: 0, available: 0 }), [filtered]);

  const criticalCount = filtered.filter(i => i.quantityAvailable <= 0).length;
  const totalPages    = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated     = useMemo(() => filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE), [filtered, page]);

  useEffect(() => { setPage(1); }, [search]);

  const fmtDate = (v?: string | null) => {
    if (!v) return "—";
    return new Date(v).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
  };

  return (
    <ProtectedRoute allowedRoles={["ADMIN", "STOCK_MANAGER"]}>
      <div className="min-h-screen bg-gray-100 dark:bg-[#060d1f] text-gray-900 dark:text-white font-mono p-6 space-y-6 transition-colors duration-300">

        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight leading-none">
              {t("stockItems")} <span className="text-[#c8202f]">Live State</span>
            </h1>
            <p className="text-xs text-gray-500 mt-1.5 uppercase tracking-widest">EMM ERP</p>
          </div>
          <button onClick={fetchItems} className="flex items-center gap-2 border border-gray-300 dark:border-white/10 hover:border-gray-400 dark:hover:border-white/20 px-4 py-2 rounded-xl text-xs uppercase tracking-wide transition text-gray-600 dark:text-gray-300">
            <RefreshCw size={13} className={loading ? "animate-spin" : ""} /> Refresh
          </button>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
          {[
            { label: t("stockItems"),  value: String(filtered.length), sub: t("tracked"),              icon: <Boxes size={16} />,    iconBg: "bg-[#c8202f]/10 text-[#c8202f]", valueColor: "text-[#c8202f]" },
            { label: t("onHand"),      value: String(totals.onHand),   sub: t("stock"),                icon: <Package size={16} />,  iconBg: "bg-blue-500/10 text-blue-400",    valueColor: "text-blue-400"    },
            { label: t("reserved"),    value: String(totals.reserved), sub: t("allocated"),             icon: <BarChart3 size={16} />,iconBg: "bg-amber-500/10 text-amber-400",  valueColor: "text-amber-400"   },
            { label: t("availableQty"),value: String(totals.available),sub: `${criticalCount} critical`,icon: <BarChart3 size={16} />,iconBg: "bg-purple-500/10 text-purple-400",valueColor: "text-purple-400"  },
          ].map((kpi, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
              className={`${card} p-5 flex items-center gap-4`}>
              <div className={`p-3 rounded-xl ${kpi.iconBg}`}>{kpi.icon}</div>
              <div>
                <p className="text-[10px] uppercase tracking-widest text-gray-500">{kpi.label}</p>
                {loading ? <div className="h-8 w-16 bg-gray-200 dark:bg-white/5 rounded animate-pulse mt-1" /> : (
                  <p className={`text-3xl font-bold tracking-tight mt-1 ${kpi.valueColor}`}>{kpi.value}</p>
                )}
                <p className="text-xs text-gray-500 mt-0.5">{kpi.sub}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Table */}
        <div className={`${card} overflow-hidden`}>
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 px-6 py-5 border-b border-gray-100 dark:border-white/[0.05]">
            <div>
              <h2 className="text-base font-bold text-gray-900 dark:text-white">{t("stockItems")}</h2>
              <p className="text-xs text-gray-500">{filtered.length} {t("ofText")} {items.length} {t("records")}</p>
            </div>
            <div className="relative">
              <Search size={12} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
              <input className="pl-8 pr-3 py-1.5 bg-gray-100 dark:bg-black/30 border border-gray-300 dark:border-white/10 rounded-lg text-xs focus:outline-none focus:border-[#c8202f]/40 transition text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-600"
                placeholder={t("searchStock")} value={search} onChange={e => setSearch(e.target.value)} />
            </div>
          </div>

          {/* Table header */}
          <div className="grid px-6 py-3 text-[10px] uppercase tracking-widest text-gray-500 dark:text-gray-600 border-b border-gray-100 dark:border-white/[0.04]"
            style={{ gridTemplateColumns: "1fr 2.5fr 1.2fr 0.8fr 0.8fr 0.8fr 1.5fr 0.8fr" }}>
            <span>{t("sku")}</span><span>{t("product")}</span><span>Type</span>
            <span>{t("onHand")}</span><span>{t("reserved")}</span><span>{t("availableQty")}</span>
            <span>{t("lastMovement")}</span><span>{t("status")}</span>
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-12 gap-2 text-gray-400"><Loader2 size={16} className="animate-spin" /> Loading…</div>
          ) : filtered.length === 0 ? (
            <div className="py-12 text-center text-xs text-gray-500 dark:text-gray-600">{t("noStockMatch")}</div>
          ) : (
            paginated.map((item, i) => {
              const p = item.productId;
              const isLow = item.quantityAvailable <= 0;
              return (
                <motion.div key={item._id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                  className={`grid px-6 py-4 items-center hover:bg-gray-50 dark:hover:bg-white/[0.02] transition ${i < paginated.length - 1 ? "border-b border-gray-100 dark:border-white/[0.03]" : ""}`}
                  style={{ gridTemplateColumns: "1fr 2.5fr 1.2fr 0.8fr 0.8fr 0.8fr 1.5fr 0.8fr" }}>

                  <p className="text-xs font-bold text-[#c8202f] font-mono">{p?.sku || "—"}</p>

                  <div className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${AVATAR_COLORS[i % AVATAR_COLORS.length]}`}>
                      {(p?.name || "?").slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-gray-900 dark:text-white">{p?.name || "—"}</p>
                      <p className="text-[10px] text-gray-400">{p?.unit || ""}</p>
                    </div>
                  </div>

                  <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{p?.type?.replace(/_/g, " ") || "—"}</p>

                  <p className="text-sm font-bold text-gray-900 dark:text-white">{item.quantityOnHand}</p>

                  <p className={`text-sm font-bold ${item.quantityReserved > 0 ? "text-amber-400" : "text-gray-500 dark:text-gray-400"}`}>
                    {item.quantityReserved}
                  </p>

                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold w-fit ${isLow ? "bg-red-500/15 text-red-400" : "bg-[#c8202f]/15 text-[#c8202f]"}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${isLow ? "bg-red-400" : "bg-[#e02d3c]"}`} />
                    {item.quantityAvailable}
                  </span>

                  <p className="text-[10px] text-gray-400 dark:text-gray-500">{fmtDate(item.lastMovementAt)}</p>

                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold w-fit ${item.status === "ACTIVE" ? "bg-[#c8202f]/15 text-[#c8202f]" : "bg-gray-100 dark:bg-white/5 text-gray-500"}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${item.status === "ACTIVE" ? "bg-[#e02d3c]" : "bg-gray-400"}`} />
                    {item.status}
                  </span>
                </motion.div>
              );
            })
          )}

          {/* Pagination */}
          {!loading && totalPages > 1 && (
            <div className="flex items-center justify-between px-6 py-4 border-t border-gray-100 dark:border-white/[0.05]">
              <p className="text-xs text-gray-500">Page {page} / {totalPages} · {filtered.length} {t("records")}</p>
              <div className="flex items-center gap-1">
                <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                  className="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 dark:border-white/10 text-gray-500 hover:bg-gray-50 dark:hover:bg-white/5 disabled:opacity-40 transition">
                  <ChevronLeft size={14} />
                </button>
                {Array.from({ length: totalPages }, (_, i) => i + 1)
                  .filter(p => p === 1 || p === totalPages || Math.abs(p - page) <= 1)
                  .reduce<(number | "…")[]>((acc, p, idx, arr) => {
                    if (idx > 0 && p - (arr[idx - 1] as number) > 1) acc.push("…");
                    acc.push(p); return acc;
                  }, [])
                  .map((p, i) => p === "…" ? (
                    <span key={`e${i}`} className="px-1 text-xs text-gray-400">…</span>
                  ) : (
                    <button key={p} onClick={() => setPage(p as number)}
                      className={`w-8 h-8 flex items-center justify-center rounded-lg text-xs font-bold transition ${page === p ? "bg-[#c8202f] text-black" : "border border-gray-200 dark:border-white/10 text-gray-500 hover:bg-gray-50 dark:hover:bg-white/5"}`}>
                      {p}
                    </button>
                  ))}
                <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
                  className="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 dark:border-white/10 text-gray-500 hover:bg-gray-50 dark:hover:bg-white/5 disabled:opacity-40 transition">
                  <ChevronRight size={14} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </ProtectedRoute>
  );
}