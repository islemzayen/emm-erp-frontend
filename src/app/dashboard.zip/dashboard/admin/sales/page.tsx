"use client";


import ProtectedRoute from "@/components/ProtectedRoute";
import { useLanguage } from "@/context/LanguageContext";
import { motion, AnimatePresence } from "framer-motion";
import {
  Users, Search, Plus, Download,
  TrendingUp, Pencil, Trash2, X, Loader2, KeyRound, Eye, EyeOff, CheckCircle,
  ShieldCheck, Clock,
} from "lucide-react";
import { useState, useEffect } from "react";
import { adminService } from "@/services/adminService";
import { salesService } from "@/services/salesService";
import CalendarPicker from "@/components/CalendarPicker";

interface Employee {
  _id: string;
  name: string;
  position: string;
  phone: string;
  email: string;
  salary: number;
  joinedDate: string;
  accountStatus: "pending" | "approved" | "none";
  role: string;
}

interface FormState {
  name: string;
  position: string;
  phone: string;
  email: string;
  salary: string;
  joinedDate: string;
}

interface Credentials {
  email: string;
  password: string;
}

const AVATAR_COLORS = [
  "bg-[#c8202f]/20 text-[#c8202f]", "bg-blue-500/20 text-blue-400",
  "bg-purple-500/20 text-purple-400",   "bg-amber-500/20 text-amber-400",
  "bg-pink-500/20 text-pink-400",       "bg-teal-500/20 text-teal-400",
  "bg-red-500/20 text-red-400",         "bg-indigo-500/20 text-indigo-400",
];

const POSITIONS = ["Employee", "Sales Manager"];

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white dark:bg-[#111c35] border border-gray-200 dark:border-white/10 rounded-2xl w-full max-w-md p-6 shadow-2xl"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-base font-bold text-gray-900 dark:text-white">{title}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-white transition">
            <X size={18} />
          </button>
        </div>
        {children}
      </motion.div>
    </div>
  );
}

export default function OnlineSalesEmployees() {
  const { t } = useLanguage();
  const [search, setSearch]       = useState("");
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading]     = useState(true);
  const [stats, setStats]         = useState({ total: 0, active: 0, onLeave: 0, avgTenure: 0 });

  const [showCreate, setShowCreate] = useState(false);
  const [showEdit, setShowEdit]     = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [showResetPw, setShowResetPw]     = useState(false);
  const [resetPwTarget, setResetPwTarget] = useState<Employee | null>(null);
  const [generatedPw, setGeneratedPw]     = useState("");
  const [resetPwError, setResetPwError]   = useState("");
  const [resetPwSuccess, setResetPwSuccess] = useState(false);
  const [resetPwSubmitting, setResetPwSubmitting] = useState(false);
  const [showGenPw, setShowGenPw]         = useState(false);
  const [copied, setCopied]               = useState(false);
  const [selected, setSelected]     = useState<Employee | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError]   = useState("");
  const [createdCredentials, setCreatedCredentials] = useState<Credentials | null>(null);
  const [approvingId, setApprovingId] = useState<string | null>(null);

  const emptyForm: FormState = {
    name: "", position: "", phone: "", email: "", salary: "",
    joinedDate: new Date().toISOString().split("T")[0],
  };
  const [form, setForm] = useState<FormState>(emptyForm);

  const card = "bg-white dark:bg-[#111c35] border border-[#1b2a6b]/15 dark:border-[#1b2a6b]/20 border-t-2 border-t-[#c8202f] rounded-2xl transition-colors duration-300 hover:shadow-[0_0_20px_#c8202f10]";
  const inputClass = "w-full px-3 py-2 bg-gray-100 dark:bg-black/30 border border-gray-200 dark:border-white/10 rounded-xl text-sm text-gray-900 dark:text-white focus:outline-none focus:border-[#c8202f]/60 transition";
  const labelClass = "text-xs text-gray-500 uppercase tracking-widest mb-1 block";

  useEffect(() => { fetchAll(); }, []);

  const fetchAll = async () => {
    try {
      setLoading(true);
      const [emps, st] = await Promise.all([salesService.getAllEmployees(), salesService.getStats()]);
      setEmployees(emps);
      setStats(st);
    } catch {} finally { setLoading(false); }
  };

  const handleCreate = async () => {
    if (!form.name || !form.position) { setFormError("Name and position are required"); return; }
    if (form.phone && form.phone.replace(/\s/g, "").length !== 8) { setFormError("Phone number must be 8 digits"); return; }
    try {
      setSubmitting(true); setFormError("");
      await salesService.createEmployee({
        name: form.name, position: form.position, phone: form.phone,
        salary: Number(form.salary) || 0, joinedDate: form.joinedDate,
      });
      await fetchAll();
      setShowCreate(false);
      setForm(emptyForm);
    } catch (err: any) { setFormError(err.response?.data?.message || "Failed to create employee"); }
    finally { setSubmitting(false); }
  };

  const openEdit = (emp: Employee) => {
    setSelected(emp);
    setForm({
      name: emp.name, position: emp.position,
      phone: emp.phone || "", email: emp.email || "",
      salary: emp.salary ? String(emp.salary) : "",
      joinedDate: emp.joinedDate ? new Date(emp.joinedDate).toISOString().split("T")[0] : "",
    });
    setFormError(""); setShowEdit(true);
  };

  const handleEdit = async () => {
    if (!form.name || !form.position) { setFormError("Name and position are required"); return; }
    if (form.phone && form.phone.replace(/\s/g, "").length !== 8) { setFormError("Phone number must be 8 digits"); return; }
    try {
      setSubmitting(true); setFormError("");
      await salesService.updateEmployee(selected!._id, {
        name: form.name, position: form.position, phone: form.phone,
        salary: Number(form.salary) || 0, joinedDate: form.joinedDate,
      });
      await fetchAll(); setShowEdit(false);
    } catch (err: any) { setFormError(err.response?.data?.message || "Failed to update employee"); }
    finally { setSubmitting(false); }
  };

  const handleDelete = async () => {
    try {
      setSubmitting(true);
      await salesService.deleteEmployee(selected!._id);
      await fetchAll(); setShowDelete(false);
    } catch {} finally { setSubmitting(false); }
  };

  const handleExport = () => {
    if (!employees.length) return;
    const headers = ["Name", "Position", "Email", "Phone", "Salary (TND)", "Joined Date"];
    const rows = employees.map(e => [
      e.name, e.position, e.email || "", e.phone || "", e.salary ?? "",
      e.joinedDate ? new Date(e.joinedDate).toLocaleDateString("en-GB") : "",
    ]);
    const csv = [headers, ...rows]
      .map(row => row.map(v => `"${String(v).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href = url; a.download = `sales-employees-${new Date().toISOString().split("T")[0]}.csv`;
    a.click(); URL.revokeObjectURL(url);
  };

  const genPassword = () => {
    const chars = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$";
    return Array.from({ length: 12 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
  };

  const openResetPw = (emp: Employee) => {
    setResetPwTarget(emp);
    setGeneratedPw(genPassword());
    setResetPwError(""); setResetPwSuccess(false);
    setShowGenPw(false); setCopied(false);
    setShowResetPw(true);
  };

  const handleResetPw = async () => {
    setResetPwSubmitting(true); setResetPwError("");
    try {
      await adminService.resetPassword(resetPwTarget!._id, generatedPw);
      setResetPwSuccess(true);
      setTimeout(() => { setShowResetPw(false); setResetPwSuccess(false); setResetPwTarget(null); }, 3500);
    } catch (err: any) {
      setResetPwError(err?.response?.data?.message || "Failed to reset password.");
    } finally { setResetPwSubmitting(false); }
  };

  const handleApprove = async (emp: Employee) => {
    setApprovingId(emp._id);
    try {
      const res  = await import("@/services/api").then(m => m.default.post(`/sales/employees/${emp._id}/approve`));
      const data = (res.data as any)?.data ?? res.data;
      await fetchAll();
      setCreatedCredentials({ email: data.email, password: data.plainPassword });
    } catch (err: any) {
      alert(err?.response?.data?.message || "Failed to approve account");
    } finally { setApprovingId(null); }
  };

  const formatDate = (d: string) =>
    d ? new Date(d).toLocaleDateString("en-GB", { month: "short", year: "numeric" }) : "—";

  const MANAGER_ROLES = ["HR_MANAGER", "MARKETING_MANAGER", "SALES_MANAGER", "ADMIN"];
  // Only show pending approval for manager-level roles — employees are created directly
  const pendingEmployees = employees.filter(e =>
    e.accountStatus === "pending" && MANAGER_ROLES.includes(e.role || "")
  );
  const normalEmployees = employees.filter(e => !pendingEmployees.find(p => p._id === e._id));
  const filtered = normalEmployees.filter(e =>
    e.name.toLowerCase().includes(search.toLowerCase()) ||
    e.position.toLowerCase().includes(search.toLowerCase()) ||
    (e.email || "").toLowerCase().includes(search.toLowerCase())
  );

  return (
    <ProtectedRoute allowedRoles={["ADMIN"]}>
    
      <div className="min-h-screen bg-gray-100 dark:bg-[#060d1f] text-gray-900 dark:text-white font-mono p-6 space-y-6 transition-colors duration-300">

        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight leading-none">
              {t("onlineSales")} <span className="text-[#c8202f]">{t("employees")}</span>
            </h1>
            <p className="text-xs text-gray-500 mt-1.5 uppercase tracking-widest">{t("onlineSalesSubtitle")}</p>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={handleExport} disabled={!employees.length}
              className="flex items-center gap-2 border border-gray-300 dark:border-white/10 hover:border-gray-400 dark:hover:border-white/20 px-4 py-2 rounded-xl text-xs uppercase tracking-wide transition text-gray-600 dark:text-gray-300 disabled:opacity-40 disabled:cursor-not-allowed">
              <Download size={13} /> {t("export")}
            </button>
            <button onClick={() => { setForm(emptyForm); setFormError(""); setShowCreate(true); }}
              className="flex items-center gap-2 bg-[#c8202f] hover:bg-[#e02d3c] px-4 py-2 rounded-xl text-xs uppercase tracking-wide transition text-black font-bold">
              <Plus size={13} /> {t("addEmployee")}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {[
            { label: t("totalEmployeesKpiShort"), value: String(stats.total),    sub: t("inDepartment"),   icon: <Users size={14} />,      iconBg: "bg-blue-500/10 text-blue-400"     },
            { label: t("avgTenure"),              value: `${stats.avgTenure}yr`, sub: t("avgPerEmployee"), icon: <TrendingUp size={14} />, iconBg: "bg-purple-500/10 text-purple-400" },
          ].map((s, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}
              className={`${card} px-5 py-4 flex items-center gap-4`}>
              <div className={`p-2 rounded-xl ${s.iconBg}`}>{s.icon}</div>
              <div>
                <p className="text-[10px] uppercase tracking-widest text-gray-500 mb-0.5">{s.label}</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white tracking-tight">{s.value}</p>
                <p className="text-xs text-gray-500 mt-0.5">{s.sub}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* ── Pending Approval Section ── */}
        {pendingEmployees.length > 0 && (
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Clock size={13} className="text-amber-400" />
              <p className="text-xs uppercase tracking-widest text-amber-400 font-bold">
                Pending Account Approval ({pendingEmployees.length})
              </p>
            </div>
            <div className={`${card} border-amber-500/20 divide-y divide-gray-100 dark:divide-white/[0.04]`}>
              {pendingEmployees.map((emp, i) => (
                <motion.div key={emp._id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.04 }}
                  className="flex items-center gap-4 px-6 py-4">
                  <div className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 bg-amber-500/20 text-amber-400">
                    {emp.name.split(" ").map((n: string) => n[0]).join("")}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-gray-900 dark:text-white">{emp.name}</p>
                    <p className="text-xs text-gray-500">{emp.position} · Online Sales</p>
                  </div>
                  <span className="text-[10px] font-bold px-2.5 py-1 rounded-full border bg-amber-500/10 text-amber-400 border-amber-500/20 hidden md:inline-flex items-center gap-1">
                    <Clock size={9} /> Awaiting Approval
                  </span>
                  <button onClick={() => handleApprove(emp)} disabled={approvingId === emp._id}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#c8202f] hover:bg-[#e02d3c] text-black text-xs font-bold transition disabled:opacity-50">
                    {approvingId === emp._id ? <Loader2 size={12} className="animate-spin" /> : <ShieldCheck size={12} />}
                    Approve
                  </button>
                  <button onClick={() => { setSelected(emp); setShowDelete(true); }}
                    className="p-1.5 rounded-lg text-red-400 hover:bg-red-500/10 transition">
                    <Trash2 size={13} />
                  </button>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        <div className={`${card} overflow-hidden`}>
          <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-5 border-b border-gray-200 dark:border-white/[0.05]">
            <div>
              <h2 className="text-base font-bold">Online Sales Team</h2>
              <p className="text-xs text-gray-500">{filtered.length} {t("ofText")} {normalEmployees.length} {t("records")}</p>
            </div>
            <div className="relative">
              <Search size={12} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input className="pl-8 pr-3 py-1.5 bg-gray-100 dark:bg-black/30 border border-gray-200 dark:border-white/10 rounded-lg text-xs focus:outline-none focus:border-[#c8202f]/40 transition text-gray-900 dark:text-white placeholder-gray-400"
                placeholder={t("searchEmployee")} value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
          </div>

          <div className="grid px-6 py-3 text-[10px] uppercase tracking-widest text-gray-500 dark:text-gray-600 border-b border-gray-100 dark:border-white/[0.04]"
            style={{ gridTemplateColumns: "2fr 2fr 1.5fr 1.2fr 1fr 100px" }}>
            <span>{t("employee")}</span><span>{t("position")}</span>
            <span>{t("phone")}</span><span>{t("salary")}</span><span>{t("joined")}</span><span>Actions</span>
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-12 text-gray-400 gap-2">
              <Loader2 size={16} className="animate-spin" /> Loading...
            </div>
          ) : filtered.length === 0 ? (
            <div className="py-12 text-center text-xs text-gray-400">{t("noEmployeesMatch")}</div>
          ) : (
            filtered.map((emp, i) => (
              <motion.div key={emp._id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.04 }}
                className={`grid px-6 py-4 items-center hover:bg-gray-50 dark:hover:bg-white/[0.02] transition ${i < filtered.length - 1 ? "border-b border-gray-100 dark:border-white/[0.03]" : ""}`}
                style={{ gridTemplateColumns: "2fr 2fr 1.5fr 1.2fr 1fr 100px" }}>
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${AVATAR_COLORS[i % AVATAR_COLORS.length]}`}>
                    {emp.name.split(" ").map((n: string) => n[0]).join("")}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-gray-900 dark:text-white">{emp.name}</p>
                    {emp.accountStatus === "approved"
                      ? <p className="text-[10px] text-gray-400">{emp.email}</p>
                      : emp.accountStatus === "pending"
                      ? <span className="text-[10px] text-amber-400 flex items-center gap-1"><Clock size={9} /> Pending approval</span>
                      : <span className="text-[10px] text-gray-500">No login account</span>
                    }
                  </div>
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400">{emp.position}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">{emp.phone || "—"}</p>
                  <p className="text-xs text-[#c8202f] font-bold">{emp.salary ? `${emp.salary.toLocaleString()} TND` : "—"}</p>
                <p className="text-xs text-gray-400 dark:text-gray-500">{formatDate(emp.joinedDate)}</p>
                <div className="flex items-center gap-1.5">
                  <button onClick={() => openEdit(emp)} className="p-1.5 rounded-lg text-blue-400 hover:bg-blue-500/10 transition" title="Edit"><Pencil size={13} /></button>
                  {emp.accountStatus === "approved" && (
                    <button onClick={() => openResetPw(emp)} className="p-1.5 rounded-lg text-amber-400 hover:bg-amber-500/10 transition" title="Reset Password"><KeyRound size={13} /></button>
                  )}
                  <button onClick={() => { setSelected(emp); setShowDelete(true); }} className="p-1.5 rounded-lg text-red-400 hover:bg-red-500/10 transition" title="Delete"><Trash2 size={13} /></button>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </div>

      <AnimatePresence>
        {showCreate && (
          <Modal title="Add Employee" onClose={() => setShowCreate(false)}>
            <div className="space-y-4">
              <div>
                <label className={labelClass}>Full Name</label>
                <input className={inputClass} placeholder="Jane Doe" value={form.name}
                  onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
                
              </div>
              <div>
                <label className={labelClass}>Position</label>
                <select className={inputClass} value={form.position} onChange={e => setForm(f => ({ ...f, position: e.target.value }))}>
                  <option value="">— Select Position —</option>
                  {POSITIONS.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
                  
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>Phone</label>
                  <input className={inputClass} placeholder="12345678" maxLength={8} value={form.phone}
                    onChange={e => setForm(f => ({ ...f, phone: e.target.value.replace(/\D/g, "") }))} />
                </div>
                <div>
                  <label className={labelClass}>Salary (TND)</label>
                  <input className={inputClass} type="text" inputMode="numeric" placeholder="0" value={form.salary}
                    onChange={e => setForm(f => ({ ...f, salary: e.target.value.replace(/\D/g, "") }))} />
                </div>
              </div>
              <CalendarPicker
                value={form.joinedDate}
                onChange={(date) => setForm(f => ({ ...f, joinedDate: date }))}
                inputClass={inputClass}
                labelClass={labelClass}
              />
              {formError && <p className="text-red-400 text-xs">{formError}</p>}
              <div className="flex gap-3 pt-2">
                <button onClick={() => setShowCreate(false)} className="flex-1 px-4 py-2 rounded-xl border border-gray-200 dark:border-white/10 text-xs text-gray-500 hover:text-gray-900 dark:hover:text-white transition">Cancel</button>
                <button onClick={handleCreate} disabled={submitting}
                  className="flex-1 px-4 py-2 rounded-xl bg-[#c8202f] hover:bg-[#e02d3c] text-black font-bold text-xs transition flex items-center justify-center gap-2">
                  {submitting ? <Loader2 size={13} className="animate-spin" /> : <Plus size={13} />} Add Employee
                </button>
              </div>
            </div>
          </Modal>
        )}

        {showEdit && selected && (
          <Modal title="Edit Employee" onClose={() => setShowEdit(false)}>
            <div className="space-y-4">
              <div>
                <label className={labelClass}>Full Name</label>
                <input className={inputClass} value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
              </div>
              <div>
                <label className={labelClass}>Position</label>
                <select className={inputClass} value={form.position} onChange={e => setForm(f => ({ ...f, position: e.target.value }))}>
                  <option value="">— Select Position —</option>
                  {POSITIONS.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>Phone</label>
                  <input className={inputClass} maxLength={8} value={form.phone}
                    onChange={e => setForm(f => ({ ...f, phone: e.target.value.replace(/\D/g, "") }))} />
                </div>
                <div>
                  <label className={labelClass}>Salary (TND)</label>
                  <input className={inputClass} type="text" inputMode="numeric" value={form.salary}
                    onChange={e => setForm(f => ({ ...f, salary: e.target.value.replace(/\D/g, "") }))}/>
                </div>
              </div>
              <div>
                <label className={labelClass}>Email</label>
                <input className={inputClass} type="email" value={form.email}
                  onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
              </div>
              <CalendarPicker
                value={form.joinedDate}
                onChange={(date) => setForm(f => ({ ...f, joinedDate: date }))}
                inputClass={inputClass}
                labelClass={labelClass}
              />
              {formError && <p className="text-red-400 text-xs">{formError}</p>}
              <div className="flex gap-3 pt-2">
                <button onClick={() => setShowEdit(false)} className="flex-1 px-4 py-2 rounded-xl border border-gray-200 dark:border-white/10 text-xs text-gray-500 hover:text-gray-900 dark:hover:text-white transition">Cancel</button>
                <button onClick={handleEdit} disabled={submitting}
                  className="flex-1 px-4 py-2 rounded-xl bg-blue-500 hover:bg-blue-400 text-white font-bold text-xs transition flex items-center justify-center gap-2">
                  {submitting ? <Loader2 size={13} className="animate-spin" /> : <Pencil size={13} />} Save Changes
                </button>
              </div>
            </div>
          </Modal>
        )}

        {showDelete && selected && (
          <Modal title="Delete Employee" onClose={() => setShowDelete(false)}>
            <div className="space-y-4">
              <p className="text-sm text-gray-500">Are you sure you want to delete <span className="text-white font-bold">{selected.name}</span>? This cannot be undone.</p>
              <div className="flex gap-3 pt-2">
                <button onClick={() => setShowDelete(false)} className="flex-1 px-4 py-2 rounded-xl border border-gray-200 dark:border-white/10 text-xs text-gray-500 hover:text-gray-900 dark:hover:text-white transition">Cancel</button>
                <button onClick={handleDelete} disabled={submitting}
                  className="flex-1 px-4 py-2 rounded-xl bg-red-500 hover:bg-red-400 text-white font-bold text-xs transition flex items-center justify-center gap-2">
                  {submitting ? <Loader2 size={13} className="animate-spin" /> : <Trash2 size={13} />} Delete
                </button>
              </div>
            </div>
          </Modal>
        )}

        {createdCredentials && (
          <Modal title={t("accountCreated")} onClose={() => setCreatedCredentials(null)}>
            <div className="space-y-4">
              <p className="text-xs text-gray-500">Share these credentials with the employee. This password will not be shown again.</p>
              <div className="space-y-3">
                <div>
                  <label className={labelClass}>Email</label>
                  <div className="flex items-center gap-2">
                    <input readOnly className={inputClass} value={createdCredentials.email} />
                    <button onClick={() => navigator.clipboard.writeText(createdCredentials.email)}
                      className="px-3 py-2 rounded-xl border border-gray-200 dark:border-white/10 text-xs text-gray-500 hover:text-gray-900 dark:hover:text-white transition whitespace-nowrap">Copy</button>
                  </div>
                </div>
                <div>
                  <label className={labelClass}>Password</label>
                  <div className="flex items-center gap-2">
                    <input readOnly className={inputClass} value={createdCredentials.password} />
                    <button onClick={() => navigator.clipboard.writeText(createdCredentials.password)}
                      className="px-3 py-2 rounded-xl border border-gray-200 dark:border-white/10 text-xs text-gray-500 hover:text-gray-900 dark:hover:text-white transition whitespace-nowrap">Copy</button>
                  </div>
                </div>
              </div>
              <div className="pt-2">
                <button onClick={() => setCreatedCredentials(null)}
                  className="w-full px-4 py-2 rounded-xl bg-[#c8202f] hover:bg-[#e02d3c] text-black font-bold text-xs transition">Done</button>
              </div>
            </div>
          </Modal>
        )}

        {showResetPw && resetPwTarget && (
          <Modal title="Reset Password" onClose={() => setShowResetPw(false)}>
            <div className="space-y-4">
              <div className="flex items-center gap-3 px-4 py-3 bg-amber-500/5 border border-amber-500/20 rounded-xl">
                <div className="w-8 h-8 rounded-full bg-amber-500/15 flex items-center justify-center flex-shrink-0">
                  <KeyRound size={14} className="text-amber-400" />
                </div>
                <div>
                  <p className="text-sm font-bold text-white">{resetPwTarget.name}</p>
                  <p className="text-[10px] text-gray-400">{resetPwTarget.email}</p>
                </div>
              </div>
              {resetPwSuccess ? (
                <div className="flex flex-col items-center gap-3 py-6">
                  <CheckCircle size={32} className="text-[#c8202f]" />
                  <p className="text-sm font-bold text-white">Password Reset Successfully</p>
                  <p className="text-xs text-gray-400 text-center">Make sure to share the password with {resetPwTarget.name}.</p>
                </div>
              ) : (
                <>
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className={labelClass}>Generated Password</label>
                      <button type="button" onClick={() => { setGeneratedPw(genPassword()); setCopied(false); }}
                        className="text-[10px] text-amber-400 hover:text-amber-300 transition uppercase tracking-wide font-bold">
                        ↺ Regenerate
                      </button>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="relative flex-1">
                        <input readOnly type={showGenPw ? "text" : "password"} value={generatedPw}
                          className={inputClass + " font-mono pr-10"} />
                        <button type="button" onClick={() => setShowGenPw(p => !p)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white transition">
                          {showGenPw ? <EyeOff size={14} /> : <Eye size={14} />}
                        </button>
                      </div>
                      <button type="button"
                        onClick={() => { navigator.clipboard.writeText(generatedPw); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
                        className={`px-3 py-2 rounded-xl text-xs font-bold border transition whitespace-nowrap ${copied ? "bg-[#c8202f]/15 border-[#c8202f]/40 text-[#c8202f]" : "border-gray-200 dark:border-white/10 text-gray-500 hover:text-white"}`}>
                        {copied ? "✓ Copied" : "Copy"}
                      </button>
                    </div>
                    <p className="text-[10px] text-gray-500 mt-1.5">Copy this password and share it with the user before confirming.</p>
                  </div>
                  {resetPwError && <p className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">{resetPwError}</p>}
                  <div className="flex gap-3 pt-2">
                    <button onClick={() => setShowResetPw(false)} className="flex-1 px-4 py-2 rounded-xl border border-gray-200 dark:border-white/10 text-xs text-gray-500 hover:text-gray-900 dark:hover:text-white transition">Cancel</button>
                    <button onClick={handleResetPw} disabled={resetPwSubmitting}
                      className="flex-1 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs transition flex items-center justify-center gap-2">
                      {resetPwSubmitting ? <Loader2 size={13} className="animate-spin" /> : <KeyRound size={13} />} Confirm Reset
                    </button>
                  </div>
                </>
              )}
            </div>
          </Modal>
        )}
      </AnimatePresence>
    
    </ProtectedRoute>
  );
}
